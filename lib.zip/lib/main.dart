// Flutter 3.35.x
// Main entry that sets up Stripe, API client, stores Dio in globals,
// and initializes the Instant registry so we can preload data on Splash.

import 'dart:async'; // runZonedGuarded
import 'dart:io'; // Platform (if you need platform checks later)
import 'package:flutter/foundation.dart'; // debugPrint
import 'package:flutter/material.dart'; // runApp, WidgetsFlutterBinding
import 'package:flutter/services.dart'; // PlatformException for Stripe
import 'package:flutter_stripe/flutter_stripe.dart'; // Stripe SDK

import 'package:shared_preferences/shared_preferences.dart'; // local prefs
import 'package:hobby_sphere/core/network/api_config.dart'; // API config reader
import 'package:hobby_sphere/core/network/api_client.dart'; // Dio builder
import 'package:hobby_sphere/core/network/globals.dart' as g; // globals holder
import 'package:hobby_sphere/core/instant/instant_register.dart'; // ✅ register loaders
import 'app/app.dart'; // root widget

Future<void> main() async {
  // Wrap the whole app to catch uncaught errors safely.
  runZonedGuarded(
    () async {
      // Make sure Flutter engine is initialized (plugins, bindings).
      WidgetsFlutterBinding.ensureInitialized(); // init Flutter

      // ---------- Stripe setup (your existing block) ----------
      try {
        // Set publishable key (test key here).
        Stripe.publishableKey =
            'pk_test_51RnLY8ROH9W55MgTYuuYpaStORtbLEggQMGOYxzYacMiDUpbfifBgThEzcMgFnvyMaskalQ0WUcQv08aByizug1I00Wcq3XHll'; // test key

        // Set custom URL scheme (must match AndroidManifest / iOS URL Types).
        Stripe.urlScheme = 'flutterstripe'; // deep link scheme

        // Apple Pay merchant identifier (also safe on Android).
        Stripe.merchantIdentifier = 'merchant.com.hobbysphere'; // merchant id

        // Apply Stripe settings now.
        await Stripe.instance.applySettings(); // initialize plugin

        // Log success in debug console.
        debugPrint('[Stripe] init OK'); // log success
      } on PlatformException catch (e, st) {
        // Stripe specific error handler (platform).
        debugPrint(
          '[Stripe] init FAIL code=${e.code} msg=${e.message} details=${e.details}',
        );
        debugPrint('$st'); // print stack
      } catch (e, st) {
        // Any other unexpected error.
        debugPrint('[Stripe] init FAIL unexpected: $e\n$st');
      }

      // ---------- API / Globals boot (your existing logic) ----------
      final cfg = await ApiConfig.load(); // read server base, timeouts, etc.
      final apiClient = ApiClient(cfg); // create Dio client with interceptors

      // Read saved token from SharedPreferences (if any).
      final sp = await SharedPreferences.getInstance(); // prefs handle
      final savedToken = sp.getString('token'); // jwt string

      // If token exists, attach it to the Dio client + globals.
      if ((savedToken ?? '').isNotEmpty) {
        apiClient.setToken(savedToken!); // set bearer on Dio
        g.Token = savedToken; // cache token in globals (your existing)
      }

      // Expose Dio and server root globally (as your app already does).
      g.appDio = apiClient.dio; // global Dio
      g.appServerRoot =
          cfg.serverRoot; // global base (e.g., https://api.../api)

      // ---------- Instant registry initialization (NEW) ----------
      // This registers lightweight loaders for user/business tabs so Splash can
      // preload data before opening Shell → the app feels instant.
      InstantRegister.init(); // ✅ register all Instant loaders once

      // Now start the app.
      runApp(const App()); // root widget
    },
    (error, stack) {
      // Fallback error logger for any uncaught exceptions.
      debugPrint('UNCAUGHT in main zone: $error\n$stack'); // safety log
    },
  );
}
