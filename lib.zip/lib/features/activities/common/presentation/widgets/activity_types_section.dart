// Home section: "Categories" + See All + grid 2 rows x 3 chips (first 6)
import 'package:flutter/material.dart'; // ui
import 'package:flutter_bloc/flutter_bloc.dart'; // bloc
import 'package:hobby_sphere/l10n/app_localizations.dart'; // i18n
import 'package:hobby_sphere/shared/widgets/top_toast.dart'; // toast

import '../../domain/usecases/get_item_types.dart'; // usecase
import '../bloc/types/types_bloc.dart'; // bloc
import '../bloc/types/types_event.dart'; // event
import '../bloc/types/types_state.dart'; // state
import 'activity_type_chip.dart'; // chip

class ActivityTypesSection extends StatelessWidget {
  final GetItemTypes getTypes; // dependency
  final String token; // bearer token
  final VoidCallback? onSeeAll; // "See All"
  final void Function(int id, String name)? onTypeTap; // chip press

  const ActivityTypesSection({
    super.key,
    required this.getTypes, // inject usecase
    required this.token, // pass token
    this.onSeeAll, // optional see all
    this.onTypeTap, // optional tap
  });

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // i18n
    final tt = Theme.of(context).textTheme; // text
    final cs = Theme.of(context).colorScheme; // colors

    return BlocProvider(
      create: (_) =>
          TypesBloc(getTypes) // create bloc
            ..add(TypesLoadRequested(token)), // load types
      child: BlocConsumer<TypesBloc, TypesState>(
        listenWhen: (p, c) => c is TypesError, // errors only
        listener: (context, state) {
          if (state is TypesError) {
            // show toast
            showTopToast(context, t.globalError, type: ToastType.error);
          }
        },
        builder: (context, state) {
          // header row
          final header = Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16), // pad
            child: Row(
              children: [
                Text(
                  t.homeActivityCategories.trim(), // title
                  style: tt.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700, // bold-ish
                  ),
                ),
                const Spacer(), // push right
                TextButton(
                  onPressed: onSeeAll, // see all action
                  child: Text(t.homeSeeAll), // label
                ),
              ],
            ),
          );

          // loading state
          if (state is TypesInitial || state is TypesLoading) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start, // align
              children: [
                const SizedBox(height: 6),
                header,
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16), // pad
                  child: GridView.count(
                    crossAxisCount: 3, // 3 per row
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10, // gaps
                    childAspectRatio: 2.3, // chip look
                    shrinkWrap: true, // no scroll
                    physics: const NeverScrollableScrollPhysics(), // fixed
                    children: List.generate(6, (i) {
                      return Container(
                        decoration: BoxDecoration(
                          color: cs.surface, // bg
                          borderRadius: BorderRadius.circular(14), // round
                          border: Border.all(
                            color: cs.outlineVariant,
                          ), // border
                        ),
                        padding: const EdgeInsets.all(12), // placeholder
                      );
                    }),
                  ),
                ),
              ],
            );
          }

          // loaded state
          if (state is TypesLoaded) {
            final six = state.types.take(6).toList(); // first 6
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start, // align
              children: [
                const SizedBox(height: 6),
                header,
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16), // pad
                  child: GridView.count(
                    crossAxisCount: 3, // 3 per row
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10, // gaps
                    childAspectRatio: 2.3, // chip look
                    shrinkWrap: true, // hug
                    physics: const NeverScrollableScrollPhysics(), // fixed
                    children: six.map((tpe) {
                      final label = tpe.name; // display name
                      return ActivityTypeChip(
                        label: label, // text
                        iconName: tpe.icon, // icon id
                        onTap: () => onTypeTap?.call(tpe.id, label), // tap
                      );
                    }).toList(),
                  ),
                ),
              ],
            );
          }

          // error fallback
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start, // align
            children: [
              const SizedBox(height: 6),
              header,
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16), // pad
                child: Text(t.globalError, style: TextStyle(color: cs.error)),
              ),
            ],
          );
        },
      ),
    );
  }
}
