// Small pressable card for one category
import 'package:flutter/material.dart'; // ui
import 'package:hobby_sphere/shared/theme/app_theme.dart'; // AppColors
import 'icon_mapper.dart'; // icon mapper

class ActivityTypeChip extends StatelessWidget {
  final String label; // chip text
  final String? iconName; // backend icon name
  final VoidCallback? onTap; // tap callback

  const ActivityTypeChip({
    super.key,
    required this.label, // need label
    this.iconName, // optional icon
    this.onTap, // optional tap
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme; // colors
    final tt = Theme.of(context).textTheme; // text

    return Material(
      color: cs.surface, // card bg
      borderRadius: BorderRadius.circular(14), // round
      child: InkWell(
        onTap: onTap, // handle tap
        borderRadius: BorderRadius.circular(14), // ripple mask
        child: Container(
          padding: const EdgeInsets.symmetric(
            // inner space
            horizontal: 10,
            vertical: 12,
          ),
          decoration: BoxDecoration(
            border: Border.all(color: cs.outlineVariant), // soft border
            borderRadius: BorderRadius.circular(14), // same radius
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min, // hug height
            children: [
              Icon(
                mapIoniconsToMaterial(iconName), // mapped icon
                size: 20, // icon size
                color: AppColors.muted, // muted color
              ),
              const SizedBox(height: 6), // gap
              Text(
                label, // text
                maxLines: 1, // one line
                overflow: TextOverflow.ellipsis, // ellipsis
                style: tt.bodyMedium, // theme text
              ),
            ],
          ),
        ),
      ),
    );
  }
}
