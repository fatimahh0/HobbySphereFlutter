// Flutter 3.35.x
// Splash page (WhatsApp-style): waits for internet, decides route,
// and now PRELOADS critical screens (user + business) → instant feel.

import 'dart:convert' as convert; // base64Url + utf8 + json
import 'package:flutter/material.dart'; // UI
import 'package:flutter_bloc/flutter_bloc.dart'; // watch/read cubit
import 'package:shared_preferences/shared_preferences.dart'; // prefs

import 'package:hobby_sphere/core/constants/app_role.dart'; // AppRole enum
import 'package:hobby_sphere/l10n/app_localizations.dart'
    show AppLocalizations; // i18n
import 'package:hobby_sphere/shared/theme/app_theme.dart'; // AppColors/AppTypography

import 'package:hobby_sphere/services/token_store.dart'; // TokenStore reader
import 'package:hobby_sphere/core/network/globals.dart' as g; // global Dio
import 'package:hobby_sphere/core/business/business_context.dart'; // business id fetcher
import 'package:hobby_sphere/app/router/router.dart'
    show ShellRouteArgs; // route args

import 'package:hobby_sphere/shared/network/connection_cubit.dart'; // ConnectionCubit
import 'package:hobby_sphere/core/instant/instant_manager.dart'; // ✅ Instant preload

class SplashPage extends StatefulWidget {
  const SplashPage({super.key}); // const ctor
  @override
  State<SplashPage> createState() => _SplashPageState(); // state handle
}

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  // ---------- Animations ----------
  late final AnimationController _progressCtrl; // progress bar controller
  late final AnimationController _bgPulseCtrl; // gradient pulse controller
  late final Animation<double> _progress; // 0..1 eased progress

  double _pageOpacity = 1.0; // for fade-out when leaving
  bool _navigated = false; // ensure single navigation

  @override
  void initState() {
    super.initState(); // parent init

    // Progress animation (3s). We loop it while not connected.
    _progressCtrl = AnimationController(
      vsync: this, // ticker
      duration: const Duration(seconds: 3), // 3 seconds full bar
    )..forward(); // start

    // Curved progression for smoother look.
    _progress = CurvedAnimation(
      parent: _progressCtrl, // base controller
      curve: Curves.easeInOut, // easing curve
    );

    // Pulse the background forever for a nice subtle effect.
    _bgPulseCtrl = AnimationController(
      vsync: this, // ticker
      duration: const Duration(milliseconds: 1800), // 1.8s pulse
    )..repeat(reverse: true); // back and forth

    // Keep looping progress while offline/connecting.
    _progressCtrl.addStatusListener((status) {
      final connected =
          context.read<ConnectionCubit>().state ==
          ConnectionStateX.connected; // online?
      if (status == AnimationStatus.completed) {
        if (!connected) {
          _progressCtrl.forward(from: 0.0); // restart progress if still offline
        }
      }
    });

    // After first frame, start the boot logic (wait internet → decide route).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _decideAndNavigate(); // run boot flow
    });
  }

  /// Decode JWT 'exp' claim and check if token is expired.
  bool _isTokenExpired(String token) {
    try {
      final parts = token.split('.'); // header.payload.signature
      if (parts.length != 3) return true; // invalid structure
      final payloadStr = _b64UrlToUtf8(parts[1]); // decode payload
      final payload =
          convert.json.decode(payloadStr) as Map<String, dynamic>; // parse json
      final exp = payload['exp'] as int?; // unix seconds
      if (exp == null) return true; // missing exp → treat as expired
      final now =
          DateTime.now().millisecondsSinceEpoch ~/ 1000; // current seconds
      return exp < now; // expired if in the past
    } catch (_) {
      return true; // any error → treat as expired for safety
    }
  }

  /// Base64Url (no padding) to UTF8 string.
  String _b64UrlToUtf8(String input) {
    final norm = convert.base64Url.normalize(input); // fix padding
    final bytes = convert.base64Url.decode(norm); // decode bytes
    return convert.utf8.decode(bytes); // to string
  }

  /// Attach token to global Dio Authorization header.
  void _attachTokenToGlobalDio(String token) {
    if (g.appDio == null) return; // guard if Dio not ready
    g.appDio!.options.headers['Authorization'] = 'Bearer $token'; // set header
  }

  /// Resolve business id (only if business role).
  Future<int> _resolveBusinessId(String token) async {
    _attachTokenToGlobalDio(token); // ensure auth header is set
    final id = await BusinessContext.ensureId(); // fetch id from backend
    return id; // return resolved id (or 0 if none)
  }

  /// Decide next route: /shell (app), /login, or onboarding screen.
  Future<_RouteTarget> _computeNext() async {
    try {
      final saved = await TokenStore.read(); // read saved token + role
      final token = saved.token?.trim(); // jwt
      final roleStr = (saved.role ?? 'user')
          .trim()
          .toLowerCase(); // role string

      if (token != null && token.isNotEmpty) {
        if (_isTokenExpired(token)) {
          await TokenStore.clear(); // remove expired
          return _RouteTarget(name: '/login'); // go to login
        }

        _attachTokenToGlobalDio(token); // set auth header

        final businessId = await _resolveBusinessId(
          token,
        ); // resolve id if business
        final appRole = roleStr == 'business'
            ? AppRole.business
            : AppRole.user; // enum

        if (appRole == AppRole.business && businessId > 0) {
          await BusinessContext.set(businessId); // cache business id
        }

        return _RouteTarget(
          name: '/shell', // main shell route
          args: ShellRouteArgs(
            role: appRole, // role
            token: token, // token
            businessId: businessId, // id (0 if none)
          ),
        );
      }

      // No token → pick onboarding vs alt onboarding based on flag.
      final sp = await SharedPreferences.getInstance(); // prefs
      final seen = sp.getBool('seen_onboarding') ?? false; // flag
      return _RouteTarget(
        name: seen ? '/onboardingScreen' : '/onboarding',
      ); // route
    } catch (e) {
      // Any failure → safe fallback to onboarding.
      debugPrint('Splash decision error: $e'); // log
      return _RouteTarget(name: '/onboarding'); // fallback
    }
  }

  /// Wait until internet connection is available (block on Splash).
  Future<void> _waitForInternet() async {
    final cubit = context.read<ConnectionCubit>(); // connection cubit
    if (cubit.state == ConnectionStateX.connected) return; // already online
    await cubit.stream.firstWhere(
      (s) => s == ConnectionStateX.connected,
    ); // wait first connected
  }

  /// Full flow: small delay → wait internet → decide route → PRELOAD → navigate.
  Future<void> _decideAndNavigate() async {
    // Small visual delay so splash doesn’t flash too quickly.
    await Future<void>.delayed(const Duration(milliseconds: 900)); // ~0.9s

    // Block here until online (WhatsApp-like).
    await _waitForInternet(); // keep on splash until we are online

    // Decide target route now.
    final target = await _computeNext(); // compute route

    // If already navigated/disposed, stop.
    if (!mounted || _navigated) return; // guard
    _navigated = true; // lock

    // ✅ PRELOAD: warm critical tabs (user + business) in parallel.
    // This makes Shell/Home open with data already available (no loading vibe).
    if (target.name == '/shell') {
      try {
        await Future.wait([
          // User side
          Instant.preload(
            'user.home',
            ctx: context,
          ), // feed + counters + lookups + precache
          Instant.preload('user.explore'), // explore page 1
          Instant.preload('user.community'), // community page 1
          Instant.preload('user.tickets'), // pending bookings
          Instant.preload('user.profile'), // profile
          // Business side
          Instant.preload(
            'biz.home',
            ctx: context,
          ), // upcoming + kpis + precache
          Instant.preload('biz.bookings'), // pending bookings
          Instant.preload('biz.analytics'), // overview
          Instant.preload('biz.activities'), // activities page 1
        ]);
      } catch (_) {
        // Ignore small preload errors; we still navigate.
      }
    }

    // Fade-out animation then navigate.
    try {
      setState(() => _pageOpacity = 0.0); // animate fade out
      await Future.delayed(const Duration(milliseconds: 180)); // tiny delay
      if (!mounted) return; // guard

      // Replace stack with target route.
      Navigator.of(context).pushNamedAndRemoveUntil(
        target.name, // route name
        (r) => false, // clear all stack
        arguments: target.args, // pass args
      );
    } catch (e) {
      // Navigation fallback in case of error.
      debugPrint('Splash navigation error: $e'); // log
      if (!mounted) return; // guard
      Navigator.of(
        context,
      ).pushNamedAndRemoveUntil('/onboarding', (r) => false); // fallback
    }
  }

  @override
  void dispose() {
    _progressCtrl.dispose(); // dispose progress controller
    _bgPulseCtrl.dispose(); // dispose background pulse
    super.dispose(); // parent dispose
  }

  // Helper: slightly lighten/darken a color (for gradient).
  Color _adjustLightness(Color c, double d) {
    final hsl = HSLColor.fromColor(c); // convert to HSL
    return hsl
        .withLightness((hsl.lightness + d).clamp(0.0, 1.0))
        .toColor(); // clamp + back
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!; // localized strings
    final primary = AppColors.primary; // theme primary
    final lighter = _adjustLightness(primary, 0.14); // lighter shade
    final darker = _adjustLightness(primary, -0.14); // darker shade

    // Watch connection cubit to render appropriate center UI.
    final conn = context.watch<ConnectionCubit>().state; // connection state

    // Prevent back button on splash (Android).
    return WillPopScope(
      onWillPop: () async => false, // disallow back
      child: Scaffold(
        backgroundColor: AppColors.background, // scaffold bg
        body: AnimatedOpacity(
          opacity: _pageOpacity, // fade value
          duration: const Duration(milliseconds: 240), // fade duration
          child: Stack(
            fit: StackFit.expand, // fill screen
            children: [
              // ---------- Pulsing gradient background ----------
              AnimatedBuilder(
                animation: _bgPulseCtrl, // listen to pulse
                builder: (context, _) {
                  final t = _bgPulseCtrl.value; // 0..1
                  final c1 = Color.lerp(primary, lighter, t)!; // mix color 1
                  final c2 = Color.lerp(primary, darker, 1 - t)!; // mix color 2
                  final begin = Alignment(
                    -0.8 + t * 0.6,
                    -0.9,
                  ); // shifting start
                  final end = Alignment(0.8 - t * 0.6, 0.9); // shifting end
                  return Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: begin, // start alignment
                        end: end, // end alignment
                        colors: [c1, c2], // gradient colors
                      ),
                    ),
                  );
                },
              ),

              // ---------- Center content based on connection state ----------
              Center(
                child: Builder(
                  builder: (context) {
                    // While connecting, show small spinner + text.
                    if (conn == ConnectionStateX.connecting) {
                      return Column(
                        mainAxisSize: MainAxisSize.min, // compact
                        children: [
                          const SizedBox(
                            width: 36,
                            height: 36,
                            child: CircularProgressIndicator(), // spinner
                          ),
                          const SizedBox(height: 12), // spacing
                          Text(
                            l10n.connectionConnecting, // "Connecting…"
                            style: AppTypography.textTheme.titleMedium, // style
                          ),
                        ],
                      );
                    }

                    // If offline, show a small warning card and a retry button.
                    if (conn == ConnectionStateX.offline) {
                      final cs = Theme.of(context).colorScheme; // color scheme
                      return Card(
                        color: cs.errorContainer, // card bg
                        margin: const EdgeInsets.all(24), // outer margin
                        child: Padding(
                          padding: const EdgeInsets.all(20), // inner padding
                          child: Column(
                            mainAxisSize: MainAxisSize.min, // wrap
                            children: [
                              Text(
                                l10n.splashNoConnectionTitle, // "No internet connection"
                                style: AppTypography.textTheme.titleLarge
                                    ?.copyWith(
                                      color: cs.onErrorContainer, // contrast
                                      fontWeight: FontWeight.w700, // bold
                                    ),
                                textAlign: TextAlign.center, // center
                              ),
                              const SizedBox(height: 8), // gap
                              Text(
                                l10n.splashNoConnectionDesc, // "Please check Wi-Fi or data and try again."
                                style: AppTypography.textTheme.bodyMedium
                                    ?.copyWith(
                                      color: cs.onErrorContainer, // contrast
                                    ),
                                textAlign: TextAlign.center, // center
                              ),
                              const SizedBox(height: 16), // gap
                              FilledButton(
                                onPressed: () => context
                                    .read<ConnectionCubit>()
                                    .retryNow(), // re-check connection
                                child: Text(
                                  l10n.connectionTryAgain,
                                ), // "Try again"
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    // When connected: show a simple logo/title while we finalize.
                    return Column(
                      mainAxisSize: MainAxisSize.min, // compact
                      children: [
                        // Circular logo placeholder
                        Container(
                          width: 112,
                          height: 112, // circle
                          decoration: BoxDecoration(
                            color: AppColors.onPrimary.withOpacity(
                              0.12,
                            ), // subtle fill
                            shape: BoxShape.circle, // circle shape
                            border: Border.all(
                              color: AppColors.onPrimary.withOpacity(
                                0.28,
                              ), // ring
                              width: 1.4, // line width
                            ),
                          ),
                          child: Icon(
                            Icons.sports_soccer, // placeholder icon
                            size: 56, // icon size
                            color: AppColors.onPrimary, // contrast color
                          ),
                        ),
                        const SizedBox(height: 18), // gap
                        Text(
                          l10n.appTitle, // localized app title
                          textAlign: TextAlign.center, // centered
                          style: AppTypography.textTheme.headlineSmall
                              ?.copyWith(
                                color: AppColors.onPrimary, // contrast
                                fontWeight: FontWeight.w700, // bold
                                letterSpacing: 0.4, // slight tracking
                              ),
                        ),
                      ],
                    );
                  },
                ),
              ),

              // ---------- Bottom looping progress bar + percent ----------
              Positioned(
                left: 0,
                right: 0,
                bottom: 0, // stick to bottom
                child: AnimatedBuilder(
                  animation: _progress, // listen to progress
                  builder: (context, _) {
                    final percent = (_progress.value * 100).toInt(); // 0..100
                    return Column(
                      mainAxisSize: MainAxisSize.min, // compact
                      children: [
                        Text(
                          "$percent%", // show percent
                          style: AppTypography.textTheme.bodyMedium?.copyWith(
                            color: AppColors.onPrimary, // contrast
                            fontWeight: FontWeight.w600, // semi-bold
                          ),
                        ),
                        LinearProgressIndicator(
                          value: _progress.value, // 0..1
                          minHeight: 8, // thickness
                          backgroundColor: AppColors.onPrimary.withOpacity(
                            0.22,
                          ), // track
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.onPrimary,
                          ), // bar
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Simple route target holder (name + optional args).
class _RouteTarget {
  final String name; // route name
  final Object? args; // route arguments
  _RouteTarget({required this.name, this.args}); // ctor
}
