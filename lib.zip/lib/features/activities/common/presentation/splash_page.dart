// splash_page.dart — Flutter 3.35.x
// Clean splash that waits for internet and server WITHOUT showing "Connecting...".
// - If NO INTERNET: show offline card (your existing one).
// - If INTERNET but SERVER DOWN: show server-down card.
// - If both OK: compute next route and navigate once.

import 'dart:convert' as convert; // base64Url + utf8 + json decode
import 'package:flutter/material.dart'; // core UI
import 'package:flutter_bloc/flutter_bloc.dart'; // for reading cubits
import 'package:shared_preferences/shared_preferences.dart'; // local storage
import 'package:dio/dio.dart'; // lightweight server probe

import 'package:hobby_sphere/core/constants/app_role.dart'; // enum AppRole
import 'package:hobby_sphere/l10n/app_localizations.dart'
    show AppLocalizations; // i18n
import 'package:hobby_sphere/shared/theme/app_theme.dart'; // AppColors/AppTypography

import 'package:hobby_sphere/services/token_store.dart'; // TokenStore (read/clear)
import 'package:hobby_sphere/core/network/globals.dart'
    as g; // global Dio client + base
import 'package:hobby_sphere/core/business/business_context.dart'; // business id holder
import 'package:hobby_sphere/app/router/router.dart'
    show ShellRouteArgs; // route args

import 'package:hobby_sphere/shared/network/connection_cubit.dart'; // ConnectionCubit + states

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

enum _ServerState { unknown, ok, down }

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  // === Animations (progress + pulsing bg) ===
  late final AnimationController _progressCtrl;
  late final AnimationController _bgPulseCtrl;
  late final Animation<double> _progress;

  double _pageOpacity = 1.0;
  bool _navigated = false;

  // NEW: server status on splash
  _ServerState _serverState = _ServerState.unknown;
  bool _probing = false; // to debounce Try again taps

  @override
  void initState() {
    super.initState();

    _progressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..forward();

    _progress = CurvedAnimation(parent: _progressCtrl, curve: Curves.easeInOut);

    _bgPulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _progressCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed && !_navigated) {
        _progressCtrl.forward(from: 0.0);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _decideAndNavigate();
    });
  }

  // ========== TOKEN HELPERS ==========

  bool _isTokenExpired(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return true;
      final payloadStr = _b64UrlToUtf8(parts[1]);
      final payload = convert.json.decode(payloadStr) as Map<String, dynamic>;
      final exp = payload['exp'] as int?;
      if (exp == null) return true;
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      return exp < now;
    } catch (_) {
      return true;
    }
  }

  String _b64UrlToUtf8(String input) {
    final norm = convert.base64Url.normalize(input);
    final bytes = convert.base64Url.decode(norm);
    return convert.utf8.decode(bytes);
  }

  void _attachTokenToGlobalDio(String token) {
    if (g.appDio == null) return;
    g.appDio!.options.headers['Authorization'] = 'Bearer $token';
  }

  Future<int> _resolveBusinessId(String token) async {
    _attachTokenToGlobalDio(token);
    final id = await BusinessContext.ensureId();
    return id;
  }

  // ========== SERVER PROBE (NEW) ==========

  /// Quick probe to confirm backend is reachable.
  /// Tries a few lightweight endpoints with short timeouts.
  Future<bool> _isServerReachableOnce() async {
    final base = (g.appServerRoot ?? '').trim();
    if (base.isEmpty) return false;

    // Build small standalone Dio to avoid interceptors/retries.
    final dio = Dio(
      BaseOptions(
        baseUrl: base, // e.g. http://host:8080/api
        connectTimeout: const Duration(seconds: 3),
        receiveTimeout: const Duration(seconds: 3),
        sendTimeout: const Duration(seconds: 3),
        followRedirects: false,
        validateStatus: (_) => true, // don't throw on non-2xx
      ),
    );

    // Candidate endpoints (you can tweak to match your backend)
    final candidates = <String>[
      '/health',
      '/ping',
      '/item-types', // known cheap GET in your app
      '/', // last resort
    ];

    for (final path in candidates) {
      try {
        final res = await dio.get(path);
        // consider reachable on any 2xx/3xx
        if (res.statusCode != null && res.statusCode! < 400) {
          return true;
        }
      } catch (_) {
        // ignore and try next
      }
    }
    return false;
  }

  /// Wait for internet, then probe server (with a couple retries, total fast).
  Future<bool> _waitForServerReachable() async {
    // small, quick retries while staying on splash
    const attempts = 3;
    for (var i = 0; i < attempts; i++) {
      final ok = await _isServerReachableOnce();
      if (ok) return true;
      await Future<void>.delayed(const Duration(seconds: 1 + 2)); // ~3s
    }
    return false;
  }

  // ========== DECISION FLOW ==========

  Future<_RouteTarget> _computeNext() async {
    try {
      final saved = await TokenStore.read();
      final token = saved.token?.trim();
      final roleStr = (saved.role ?? 'user').trim().toLowerCase();

      if (token != null && token.isNotEmpty) {
        if (_isTokenExpired(token)) {
          await TokenStore.clear();
          return _RouteTarget(name: '/login');
        }

        _attachTokenToGlobalDio(token);

        final businessId = await _resolveBusinessId(token);
        final appRole = roleStr == 'business' ? AppRole.business : AppRole.user;

        if (appRole == AppRole.business && businessId > 0) {
          await BusinessContext.set(businessId);
        }

        return _RouteTarget(
          name: '/shell',
          args: ShellRouteArgs(
            role: appRole,
            token: token,
            businessId: businessId,
          ),
        );
      }

      final sp = await SharedPreferences.getInstance();
      final seen = sp.getBool('seen_onboarding') ?? false;
      return _RouteTarget(name: seen ? '/onboardingScreen' : '/onboarding');
    } catch (e) {
      debugPrint('Splash decision error: $e');
      return _RouteTarget(name: '/onboarding');
    }
  }

  Future<void> _waitForInternet() async {
    final cubit = context.read<ConnectionCubit>();
    if (cubit.state == ConnectionStateX.connected) return;
    await cubit.stream.firstWhere((s) => s == ConnectionStateX.connected);
  }

  /// Main flow: wait internet → probe server → compute route → navigate.
  Future<void> _decideAndNavigate() async {
    // tiny delay for visuals
    await Future<void>.delayed(const Duration(milliseconds: 600));

    // 1) INTERNET (same behavior: no "Connecting..." on Splash)
    await _waitForInternet();

    // 2) SERVER: probe; if down, show server card and stop here
    setState(() {
      _probing = true;
      _serverState = _ServerState.unknown;
    });
    final serverOk = await _waitForServerReachable();
    if (!mounted) return;

    if (!serverOk) {
      setState(() {
        _probing = false;
        _serverState = _ServerState.down; // show server-down card
      });
      return; // stay on splash until user tries again and it passes
    }

    setState(() {
      _probing = false;
      _serverState = _ServerState.ok;
    });

    // 3) compute next and navigate
    final target = await _computeNext();
    if (!mounted || _navigated) return;
    _navigated = true;

    try {
      setState(() => _pageOpacity = 0.0);
      await Future.delayed(const Duration(milliseconds: 180));
      if (!mounted) return;

      Navigator.of(context).pushNamedAndRemoveUntil(
        target.name,
        (r) => false,
        arguments: target.args,
      );
    } catch (e) {
      debugPrint('Splash navigation error: $e');
      if (!mounted) return;
      Navigator.of(
        context,
      ).pushNamedAndRemoveUntil('/onboarding', (r) => false);
    }
  }

  @override
  void dispose() {
    _progressCtrl.dispose();
    _bgPulseCtrl.dispose();
    super.dispose();
  }

  // ========== UI HELPERS ==========

  Color _adjustLightness(Color c, double d) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness + d).clamp(0.0, 1.0)).toColor();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final primary = AppColors.primary;
    final lighter = _adjustLightness(primary, 0.14);
    final darker = _adjustLightness(primary, -0.14);

    final conn = context.watch<ConnectionCubit>().state;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: AnimatedOpacity(
          opacity: _pageOpacity,
          duration: const Duration(milliseconds: 240),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // pulsing gradient bg
              AnimatedBuilder(
                animation: _bgPulseCtrl,
                builder: (context, _) {
                  final t = _bgPulseCtrl.value;
                  final c1 = Color.lerp(primary, lighter, t)!;
                  final c2 = Color.lerp(primary, darker, 1 - t)!;
                  final begin = Alignment(-0.8 + t * 0.6, -0.9);
                  final end = Alignment(0.8 - t * 0.6, 0.9);
                  return Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: begin,
                        end: end,
                        colors: [c1, c2],
                      ),
                    ),
                  );
                },
              ),

              // center content
              Center(
                child: Builder(
                  builder: (context) {
                    // OFFLINE → existing card
                    if (conn == ConnectionStateX.offline) {
                      final cs = Theme.of(context).colorScheme;
                      return Card(
                        color: cs.errorContainer,
                        margin: const EdgeInsets.all(24),
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                l10n.splashNoConnectionTitle,
                                style: AppTypography.textTheme.titleLarge
                                    ?.copyWith(
                                      color: cs.onErrorContainer,
                                      fontWeight: FontWeight.w700,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                l10n.splashNoConnectionDesc,
                                style: AppTypography.textTheme.bodyMedium
                                    ?.copyWith(color: cs.onErrorContainer),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 16),
                              FilledButton(
                                onPressed: () =>
                                    context.read<ConnectionCubit>().retryNow(),
                                child: Text(l10n.connectionTryAgain),
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    // SERVER DOWN (internet OK)
                    if (_serverState == _ServerState.down && !_probing) {
                      final cs = Theme.of(context).colorScheme;
                      return Card(
                        color: cs.surfaceContainerHighest,
                        margin: const EdgeInsets.all(24),
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                l10n.splashServerDownTitle, // NEW string
                                style: AppTypography.textTheme.titleLarge
                                    ?.copyWith(
                                      color: cs.onSurface,
                                      fontWeight: FontWeight.w700,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                l10n.splashServerDownDesc, // NEW string
                                style: AppTypography.textTheme.bodyMedium
                                    ?.copyWith(color: cs.onSurfaceVariant),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 16),
                              FilledButton(
                                onPressed: _probing
                                    ? null
                                    : () async {
                                        setState(() {
                                          _probing = true;
                                          _serverState = _ServerState.unknown;
                                        });
                                        final ok =
                                            await _waitForServerReachable();
                                        if (!mounted) return;
                                        if (ok) {
                                          setState(() {
                                            _probing = false;
                                            _serverState = _ServerState.ok;
                                          });
                                          _decideAndNavigate(); // resume flow
                                        } else {
                                          setState(() {
                                            _probing = false;
                                            _serverState = _ServerState.down;
                                          });
                                        }
                                      },
                                child: _probing
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : Text(l10n.connectionTryAgain),
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    // CONNECTING or CONNECTED and server not known-down → logo only
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 112,
                          height: 112,
                          decoration: BoxDecoration(
                            color: AppColors.onPrimary.withOpacity(0.12),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppColors.onPrimary.withOpacity(0.28),
                              width: 1.4,
                            ),
                          ),
                          child: const Icon(
                            Icons.sports_soccer,
                            size: 56,
                            color: AppColors.onPrimary,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Text(
                          l10n.appTitle,
                          textAlign: TextAlign.center,
                          style: AppTypography.textTheme.headlineSmall
                              ?.copyWith(
                                color: AppColors.onPrimary,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.4,
                              ),
                        ),
                      ],
                    );
                  },
                ),
              ),

              // bottom looping progress
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: AnimatedBuilder(
                  animation: _progress,
                  builder: (context, _) {
                    final percent = (_progress.value * 100).toInt();
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "$percent%",
                          style: AppTypography.textTheme.bodyMedium?.copyWith(
                            color: AppColors.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        LinearProgressIndicator(
                          value: _progress.value,
                          minHeight: 8,
                          backgroundColor: AppColors.onPrimary.withOpacity(
                            0.22,
                          ),
                          valueColor: const AlwaysStoppedAnimation<Color>(
                            AppColors.onPrimary,
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RouteTarget {
  final String name;
  final Object? args;
  _RouteTarget({required this.name, this.args});
}
