// Screen – Show all categories in grid (3 columns)
import 'package:flutter/material.dart'; // ui
import 'package:flutter_bloc/flutter_bloc.dart'; // bloc
import 'package:hobby_sphere/l10n/app_localizations.dart'; // i18n
import 'package:hobby_sphere/shared/widgets/top_toast.dart'; // toast

import '../../domain/usecases/get_item_types.dart'; // usecase
import '../bloc/types/types_bloc.dart'; // bloc
import '../bloc/types/types_event.dart'; // event
import '../bloc/types/types_state.dart'; // state
import '../widgets/activity_type_chip.dart'; // chip

class ActivityTypesAllScreen extends StatelessWidget {
  final GetItemTypes getTypes; // dependency
  final String token; // bearer token
  final void Function(int id, String name)? onTypeTap; // tap callback

  const ActivityTypesAllScreen({
    super.key,
    required this.getTypes, // inject
    required this.token, // pass token
    this.onTypeTap, // optional
  });

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // i18n
    final cs = Theme.of(context).colorScheme; // colors

    return Scaffold(
      appBar: AppBar(title: Text(t.homeSeeAllCategories)), // appbar
      body: BlocProvider(
        create: (_) =>
            TypesBloc(getTypes) // bloc
              ..add(TypesLoadRequested(token)), // load
        child: BlocConsumer<TypesBloc, TypesState>(
          listenWhen: (p, c) => c is TypesError, // listen errors
          listener: (context, state) {
            if (state is TypesError) {
              showTopToast(context, t.globalError, type: ToastType.error);
            }
          },
          builder: (context, state) {
            if (state is TypesInitial || state is TypesLoading) {
              return const Center(
                child: CircularProgressIndicator(),
              ); // spinner
            }
            if (state is TypesLoaded) {
              final list = state.types; // data
              return GridView.builder(
                padding: const EdgeInsets.all(16), // pad
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, // 3 per row
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 2.3, // chip look
                ),
                itemCount: list.length, // count
                itemBuilder: (_, i) {
                  final tpe = list[i]; // item
                  return ActivityTypeChip(
                    label: tpe.name, // text
                    iconName: tpe.icon, // icon
                    onTap: () => onTypeTap?.call(tpe.id, tpe.name), // tap
                  );
                },
              );
            }
            return Center(
              // error UI
              child: Text(t.globalError, style: TextStyle(color: cs.error)),
            );
          },
        ),
      ),
    );
  }
}
