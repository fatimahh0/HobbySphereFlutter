import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hobby_sphere/core/network/globals.dart' as g;
import 'package:hobby_sphere/app/bootstrap/start_user_realtime.dart' as rt;
import 'package:hobby_sphere/core/realtime/user_realtime_bridge.dart'
    show Remover;
import 'package:hobby_sphere/features/activities/user/social/domain/entities/user_min.dart';
import 'package:hobby_sphere/features/activities/user/social/presentation/widgets/chat_bubble.dart';
import 'package:hobby_sphere/l10n/app_localizations.dart';
import 'package:image_picker/image_picker.dart';

import '../bloc/chat/chat_bloc.dart';
import '../bloc/chat/chat_event.dart';
import '../bloc/chat/chat_state.dart';
import '../../domain/entities/chat_message.dart';

/// WhatsApp-like conversation UI (text + image) + realtime incoming.
/// NOTE: [meId] is OPTIONAL now → keeps old router working.
class ConversationScreen extends StatefulWidget {
  final UserMin peer; // the contact you chat with
  final int? meId; // <-- optional (to avoid router changes)

  const ConversationScreen({
    super.key,
    required this.peer,
    this.meId, // optional
  });

  @override
  State<ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<ConversationScreen> {
  final _ctrl = TextEditingController();
  final _picker = ImagePicker();

  late final Remover _rmMessageCreated;
  int get _peerId => widget.peer.id;

  // -- small safe parsers -----------------------------------------------------
  DateTime _parseDate(dynamic v) {
    if (v is DateTime) return v;
    if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
    if (v is int) return DateTime.fromMillisecondsSinceEpoch(v);
    return DateTime.now();
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) {
      final n = int.tryParse(v);
      if (n != null) return n;
    }
    return 0;
  }

  /// Map socket JSON → ChatMessage (fills all required named params).
  /// We don’t rely on a global `userId`. If [meId] is not provided,
  /// we infer `isMine` by: sender != peer → mine, sender == peer → not mine.
  ChatMessage _mapSocketMsg(Map<String, dynamic> m) {
    final sender = _asInt(m['fromUserId'] ?? m['senderId']);
    final receiver = _asInt(m['toUserId'] ?? m['receiverId']);
    final sentAt = _parseDate(m['createdAt'] ?? m['sentAt']);
    final isRead = (m['isRead'] == true) || (m['read'] == true);

    // If caller passed meId, use it, otherwise infer from peerId.
    final bool isMine = widget.meId != null
        ? (sender == widget.meId)
        : (sender != _peerId);

    return ChatMessage(
      id: _asInt(m['id']),
      senderId: sender, // REQUIRED
      receiverId: receiver, // REQUIRED
      text: m['text'] as String?,
      imageUrl: m['imageUrl'] as String?,
      sentAt: sentAt, // REQUIRED
      isRead: isRead, // REQUIRED
      isMine: isMine, // for bubble alignment
    );
  }

  String? _resolve(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    if (raw.startsWith('http')) return raw;
    final root = (g.appServerRoot ?? '').replaceFirst(RegExp(r'/api/?$'), '');
    return raw.startsWith('/') ? '$root$raw' : '$root/$raw';
  }

  @override
  void initState() {
    super.initState();
    // Load the initial conversation
    context.read<ChatBloc>().add(LoadConversation(_peerId));

    // Realtime: listen to "message.created" and append if it's for this peer
    _rmMessageCreated = rt.userBridge.onMessageCreatedListen((convId, msg) {
      final from = _asInt(msg['fromUserId'] ?? msg['senderId']);
      final to = _asInt(msg['toUserId'] ?? msg['receiverId']);

      // In 1:1, either from==peerId (their msg) or to==peerId (my msg)
      if (from == _peerId || to == _peerId) {
        final cm = _mapSocketMsg(msg);
        if (!mounted) return;
        context.read<ChatBloc>().add(PushIncoming(cm));

        // Optional: mark read when an id exists
        final mid = _asInt(msg['id']);
        if (mid != 0) {
          context.read<ChatBloc>().add(MarkOneRead(mid));
        }
      }
    });
  }

  @override
  void dispose() {
    _rmMessageCreated();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10 = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: cs.surfaceVariant,
              backgroundImage: (_resolve(widget.peer.profileImageUrl) != null)
                  ? NetworkImage(_resolve(widget.peer.profileImageUrl)!)
                  : null,
              child: (_resolve(widget.peer.profileImageUrl) == null)
                  ? Text(
                      (widget.peer.firstName.isNotEmpty
                              ? widget.peer.firstName[0]
                              : '?')
                          .toUpperCase(),
                    )
                  : null,
            ),
            const SizedBox(width: 8),
            Text(widget.peer.fullName),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // messages
            Expanded(
              child: BlocBuilder<ChatBloc, ChatState>(
                builder: (_, st) {
                  if (st.isLoading && st.messages.isEmpty) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: st.messages.length,
                    itemBuilder: (_, i) => Align(
                      alignment: st.messages[i].isMine
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: ChatBubble(m: st.messages[i]),
                    ),
                  );
                },
              ),
            ),

            // input
            SafeArea(
              top: false,
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.image_outlined),
                    onPressed: () async {
                      final x = await _picker.pickImage(
                        source: ImageSource.gallery,
                        imageQuality: 80,
                      );
                      if (x != null) {
                        context.read<ChatBloc>().add(
                          SendImage(_peerId, x.path),
                        );
                      }
                    },
                  ),
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      minLines: 1,
                      maxLines: 5,
                      decoration: InputDecoration(
                        hintText: l10.friendChat,
                        filled: true,
                        fillColor: cs.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.send_rounded),
                    color: cs.primary,
                    onPressed: () {
                      final txt = _ctrl.text.trim();
                      if (txt.isEmpty) return;
                      context.read<ChatBloc>().add(SendText(_peerId, txt));
                      _ctrl.clear();
                    },
                  ),
                  const SizedBox(width: 6),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
