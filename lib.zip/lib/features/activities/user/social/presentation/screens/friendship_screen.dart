// friendship hub — realtime refresh across three tabs.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hobby_sphere/app/bootstrap/start_user_realtime.dart' as rt;
import 'package:hobby_sphere/core/realtime/user_realtime_bridge.dart'
    show Remover;
import 'package:hobby_sphere/features/activities/user/social/presentation/widgets/user_tile.dart';
import 'package:hobby_sphere/shared/widgets/top_toast.dart';
import 'package:hobby_sphere/l10n/app_localizations.dart';
import '../bloc/friends/friends_bloc.dart';
import '../bloc/friends/friends_event.dart';
import '../bloc/friends/friends_state.dart';

class FriendshipScreen extends StatefulWidget {
  final int initialTab; // 0 rec, 1 sent, 2 friends
  const FriendshipScreen({super.key, this.initialTab = 0});

  @override
  State<FriendshipScreen> createState() => _FriendshipScreenState();
}

class _FriendshipScreenState extends State<FriendshipScreen> {
  late int tab;
  String q = '';

  late final Remover _rmFrR;

  @override
  void initState() {
    super.initState();
    tab = widget.initialTab;
    final b = context.read<FriendsBloc>();
    b.add(const LoadReceived());
    b.add(const LoadSent());
    b.add(const LoadFriends());

    // realtime: refresh all lists when any friendship updates
    _rmFrR = rt.userBridge.onFriendshipUpdatedListen((_) {
      final bloc = context.read<FriendsBloc>();
      bloc.add(const LoadReceived());
      bloc.add(const LoadSent());
      bloc.add(const LoadFriends());
    });
  }

  @override
  void dispose() {
    _rmFrR();
    super.dispose();
  }

  List<T> _filterByName<T>(List<T> src, String Function(T) getter) {
    final s = q.trim().toLowerCase();
    if (s.isEmpty) return src;
    return src.where((e) => getter(e).toLowerCase().contains(s)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final l10 = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: Text('')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                onChanged: (v) => setState(() => q = v),
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: l10.friendshipAddFriendSearchPlaceholder,
                  filled: true,
                  fillColor: cs.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(28),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: _Seg(
                      label: l10.friendshipReceivedRequests,
                      selected: tab == 0,
                      onTap: () => setState(() => tab = 0),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Seg(
                      label: l10.friendshipSentRequests,
                      selected: tab == 1,
                      onTap: () => setState(() => tab = 1),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Seg(
                      label: l10.friendshipMyFriends,
                      selected: tab == 2,
                      onTap: () => setState(() => tab = 2),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: BlocConsumer<FriendsBloc, FriendsState>(
                listener: (ctx, st) {
                  if (st.error != null && st.error!.isNotEmpty) {
                    showTopToast(
                      context,
                      l10.friendshipErrorFailedAction,
                      type: ToastType.error,
                    );
                  }
                },
                builder: (ctx, st) {
                  final loadingAll =
                      st.isLoading &&
                      st.received.isEmpty &&
                      st.sent.isEmpty &&
                      st.friends.isEmpty;
                  if (loadingAll)
                    return const Center(child: CircularProgressIndicator());

                  if (tab == 0) {
                    final list = _filterByName(
                      st.received,
                      (r) => r.user.fullName,
                    );
                    if (list.isEmpty)
                      return Center(child: Text(l10.friendshipNoRequests));
                    return ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 0),
                      itemBuilder: (_, i) {
                        final r = list[i];
                        return UserTile(
                          user: r.user,
                          subtitle: l10.friendTab_received,
                          trailing: Wrap(
                            spacing: 6,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.check_circle_outline),
                                color: cs.primary,
                                onPressed: () {
                                  final b = context.read<FriendsBloc>();
                                  b.add(AcceptRequest(r.requestId));
                                  b.add(const LoadFriends());
                                  b.add(const LoadReceived());
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.close_rounded),
                                color: cs.error,
                                onPressed: () {
                                  final b = context.read<FriendsBloc>();
                                  b.add(RejectRequest(r.requestId));
                                  b.add(const LoadReceived());
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }

                  if (tab == 1) {
                    final list = _filterByName(st.sent, (r) => r.user.fullName);
                    if (list.isEmpty)
                      return Center(child: Text(l10.friendshipNoRequests));
                    return ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 0),
                      itemBuilder: (_, i) {
                        final r = list[i];
                        return UserTile(
                          user: r.user,
                          subtitle: l10.friendTab_sent,
                          trailing: IconButton(
                            icon: const Icon(Icons.cancel_outlined),
                            color: cs.onSurfaceVariant,
                            onPressed: () {
                              final bloc = context.read<FriendsBloc>();
                              bloc.add(RemoveSentLocal(r.requestId));
                              bloc.add(CancelRequest(r.requestId));
                              bloc.add(const LoadSent());
                            },
                          ),
                        );
                      },
                    );
                  }

                  final list = _filterByName(st.friends, (u) => u.fullName);
                  if (list.isEmpty)
                    return Center(child: Text(l10.friendshipNoFriends));
                  return ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 0),
                    itemBuilder: (_, i) {
                      final u = list[i];
                      return UserTile(
                        user: u,
                        subtitle: l10.friendTabFriends,
                        trailing: IconButton(
                          icon: const Icon(Icons.person_remove_alt_1_outlined),
                          color: cs.onSurfaceVariant,
                          onPressed: () {
                            final b = context.read<FriendsBloc>();
                            b.add(UnfriendUser(u.id));
                            b.add(const LoadFriends());
                          },
                        ),
                        onTap: () {
                          Navigator.of(
                            context,
                          ).pushNamed('/community/chat', arguments: u);
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Seg extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Seg({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: selected ? cs.primary : cs.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Center(
            child: Text(
              label,
              style: TextStyle(color: selected ? cs.onPrimary : cs.onSurface),
            ),
          ),
        ),
      ),
    );
  }
}
