// Flutter 3.35.x
// User Home screen (your current structure).
// It will already feel instant because Splash preloads 'user.home' +
// warms images, and your Home fetchers hit hot caches.
// Code below is your original with clear comments line-by-line.

import 'package:flutter/material.dart'; // UI
import 'package:flutter_bloc/flutter_bloc.dart'; // BLoC helpers
import 'package:hobby_sphere/app/router/router.dart'; // route names + args
import 'package:hobby_sphere/features/activities/user/userNotification/data/repositories/user_notification_repository_impl.dart'; // repo
import 'package:hobby_sphere/features/activities/user/userNotification/data/services/user_notification_service.dart'; // service
import 'package:hobby_sphere/features/activities/user/userNotification/presentation/bloc/user_unread_cubit.dart'; // unread cubit
import 'package:hobby_sphere/l10n/app_localizations.dart'; // l10n
import 'package:hobby_sphere/core/network/globals.dart' as g; // server root

// Sections (widgets for content blocks)
import 'package:hobby_sphere/features/activities/user/userHome/presentation/widgets/interest_section.dart';
import 'package:hobby_sphere/features/activities/user/userHome/presentation/widgets/explore_section.dart';
import 'package:hobby_sphere/features/activities/common/presentation/widgets/activity_types_section.dart';
import 'package:hobby_sphere/features/activities/common/presentation/screens/activity_types_all_screen.dart';
import 'package:hobby_sphere/features/activities/common/presentation/screens/activities_by_type_screen.dart';

// Usecases (domain layer)
import 'package:hobby_sphere/features/activities/user/userHome/domain/usecases/get_interest_based_items.dart';
import 'package:hobby_sphere/features/activities/user/userHome/domain/usecases/get_upcoming_guest_items.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_item_types.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_items_by_type.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_current_currency.dart';

// Data layer for currency (repository + service)
import 'package:hobby_sphere/features/activities/common/data/repositories/currency_repository_impl.dart';
import 'package:hobby_sphere/features/activities/common/data/services/currency_service.dart';

// Header widget (avatar, bell, counts)
import 'package:hobby_sphere/features/activities/user/common/presentation/widgets/home_header.dart';

// Search bar widget
import 'package:hobby_sphere/shared/widgets/app_search_bar.dart';

class UserHomeScreen extends StatelessWidget {
  // Header name parts (first/last) — we avoid showing usernames publicly.
  final String? firstName; // first name
  final String? lastName; // last name
  final String? avatarUrl; // avatar
  final int unreadCount; // starting unread count (can be 0)

  // Auth and user identity
  final String token; // JWT token (empty for guest)
  final int userId; // numeric user id (<=0 for guest)

  // Usecases used by sections
  final GetInterestBasedItems getInterestBased; // interest section UC
  final GetUpcomingGuestItems getUpcomingGuest; // explore section UC
  final GetItemTypes getItemTypes; // types UC
  final GetItemsByType getItemsByType; // items by type UC

  // Currency helpers
  final String? currencyFallback; // e.g., 'USD'
  final Future<String?> Function()? getCurrencyCode; // optional getter

  const UserHomeScreen({
    super.key,
    this.firstName,
    this.lastName,
    this.avatarUrl,
    this.unreadCount = 0,
    required this.token,
    required this.userId,
    required this.getInterestBased,
    required this.getUpcomingGuest,
    required this.getItemTypes,
    required this.getItemsByType,
    this.currencyFallback,
    this.getCurrencyCode,
  });

  // Helper to get server root without trailing /api.
  String _serverRoot() {
    final base = (g.appServerRoot ?? ''); // base like https://api.../api
    return base.replaceFirst(
      RegExp(r'/api/?$'),
      '',
    ); // strip /api → https://api...
  }

  // Navigate to details screen (guest-safe).
  void _goToDetails(BuildContext context, int itemId, String imageBaseUrl) {
    // Ensure "Bearer " prefix only when token is non-empty.
    final bearer = token.trim().isEmpty
        ? '' // guest
        : (token.startsWith('Bearer ') ? token : 'Bearer $token'); // auth

    // Push details route with arguments (token null for guest).
    Navigator.of(context).pushNamed(
      Routes.userActivityDetail, // route name
      arguments: UserActivityDetailRouteArgs(
        itemId: itemId, // activity id
        token: bearer.isNotEmpty ? bearer : null, // null if guest
        currencyCode: currencyFallback, // currency code
        imageBaseUrl: imageBaseUrl, // absolute base for images
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // localized strings
    final serverRoot = _serverRoot(); // image base url

    // Decide guest vs logged-in mode once.
    final bool isGuest = token.trim().isEmpty || userId <= 0; // guest if true

    // Currency code getter (safe with fallback).
    final getCurrencyCodeFn =
        getCurrencyCode ??
        (() async {
          try {
            // Build UC for currency (simple call).
            final usecase = GetCurrentCurrency(
              CurrencyRepositoryImpl(CurrencyService()),
            );
            final cur = await usecase(token); // may be guest token ('')
            return cur.code; // e.g., "USD"
          } catch (_) {
            return currencyFallback; // fallback if anything fails
          }
        });

    // ---------- Header builder (guest vs logged-in) ----------
    Widget _buildHeader(BuildContext ctx, {int liveUnread = 0}) {
      if (isGuest) {
        // Guest: bell disabled and unread always 0.
        return HomeHeader(
          firstName: null, // hide name
          lastName: null, // hide name
          avatarUrl: null, // hide avatar
          unreadCount: 0, // no count for guest
          margin: EdgeInsets.zero, // no outer margin
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 8), // inner padding
          radius: 10, // rounded
          onBellTap: null, // disabled in guest
        );
      }

      // Logged-in: show unread and open notifications on tap.
      return HomeHeader(
        firstName: firstName, // display first name
        lastName: lastName, // display last name
        avatarUrl: avatarUrl, // avatar url
        unreadCount: liveUnread, // live count from cubit
        margin: EdgeInsets.zero, // no margin
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 8), // padding
        radius: 10, // rounded
        onBellTap: () {
          // Navigate to notifications, then refresh count on return.
          Navigator.of(ctx)
              .pushNamed(
                Routes.userNotifications, // route
                arguments: UserNotificationsRouteArgs(token: token), // args
              )
              .then((_) {
                final cubit = ctx.read<UserUnreadNotificationsCubit>(); // cubit
                cubit.refresh(); // refresh on return
              });
        },
      );
    }

    // ---------- Main list body shared for both modes ----------
    Widget _buildContent(BuildContext ctx, {int liveUnread = 0}) {
      return ListView(
        padding: EdgeInsets.zero, // no list outer padding
        children: [
          _buildHeader(ctx, liveUnread: liveUnread), // top header

          const Divider(height: 1), // small divider
          // Interest-based section (only for logged-in).
          if (!isGuest)
            InterestSection(
              title: t.homeInterestBasedTitle, // title text
              showAllLabel: t.homeSeeAll, // "See all"
              usecase: getInterestBased, // UC
              token: token, // bearer or ''
              userId: userId, // id
              currencyCode: currencyFallback, // fallback
              getCurrencyCode: getCurrencyCodeFn, // currency getter
              imageBaseUrl: serverRoot, // absolute image base
              maxItems: 4, // limit to 4 cards
              standalone: false, // used inside home
              onItemTap: (id) {
                // Optional: hook to details
                _goToDetails(ctx, id, serverRoot);
              },
              onShowAll: () {
                // Navigate to "all" page for interest-based.
                Navigator.of(ctx).push(
                  MaterialPageRoute(
                    builder: (_) => _AllInterestsPage(
                      getInterestBased: getInterestBased, // pass UC
                      token: token, // token
                      userId: userId, // id
                      currencyFallback: currencyFallback, // code
                      getCurrencyCode: getCurrencyCodeFn, // getter
                      imageBaseUrl: serverRoot, // base
                    ),
                  ),
                );
              },
            ),

          const SizedBox(height: 6), // small gap
          // Activity types section (works for guest).
          ActivityTypesSection(
            getTypes: getItemTypes, // UC
            getItemsByType: getItemsByType, // UC
            token: token, // '' is ok for guest if API supports
            onlyWithActivities: true, // filter types that have items
            onTypeTap: (id, name) {
              // Navigate to list of activities by a specific type.
              Navigator.of(ctx).push(
                MaterialPageRoute(
                  builder: (_) => ActivitiesByTypeScreen(
                    typeId: id, // type id
                    typeName: name, // type name
                    getItemsByType: getItemsByType, // UC
                    currencyCode: currencyFallback, // fallback
                    getCurrencyCode: getCurrencyCodeFn, // getter
                    imageBaseUrl: serverRoot, // base
                  ),
                ),
              );
            },
            onSeeAll: () {
              // Full list of categories (types).
              Navigator.of(ctx).push(
                MaterialPageRoute(
                  builder: (_) => ActivityTypesAllScreen(
                    getTypes: getItemTypes, // UC
                    getItemsByType: getItemsByType, // UC
                    token: token, // token or guest
                    onTypeTap: (id, name) {
                      // In "all types", open "by type" screen.
                      Navigator.of(ctx).push(
                        MaterialPageRoute(
                          builder: (_) => ActivitiesByTypeScreen(
                            typeId: id, // type id
                            typeName: name, // type name
                            getItemsByType: getItemsByType, // UC
                            currencyCode: currencyFallback, // fallback
                            imageBaseUrl: serverRoot, // base
                          ),
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 6), // small gap
          // Explore section (works for guest).
          ExploreSection(
            title: t.homeExploreActivities, // section title
            showAllLabel: t.homeSeeAll, // "See all"
            usecase: getUpcomingGuest, // UC
            currencyCode: currencyFallback, // fallback
            getCurrencyCode: getCurrencyCodeFn, // getter
            imageBaseUrl: serverRoot, // base
            maxItems: 6, // show 6 cards
            standalone: false, // in home
            onItemTap: (id) {
              // Optional: hook to details
              _goToDetails(ctx, id, serverRoot);
            },
            onShowAll: () {
              // Navigate to Explore "see-all" page.
              Navigator.of(ctx).push(
                MaterialPageRoute(
                  builder: (_) => _AllExplorePage(
                    getUpcomingGuest: getUpcomingGuest, // UC
                    currencyFallback: currencyFallback, // fallback
                    getCurrencyCode: getCurrencyCodeFn, // getter
                    imageBaseUrl: serverRoot, // base
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 16), // bottom spacing
        ],
      );
    }

    // ---------- Return guest vs logged-in scaffold ----------
    if (isGuest) {
      // Guest: no cubit provided → avoids unread API/401.
      return Scaffold(
        body: SafeArea(
          top: true,
          bottom: false, // insets
          child: _buildContent(context), // render list
        ),
      );
    }

    // Logged-in: provide unread cubit so bell count updates.
    return BlocProvider<UserUnreadNotificationsCubit>(
      create: (_) {
        final repo = UserNotificationRepositoryImpl(
          UserNotificationService(),
        ); // repo
        final cubit = UserUnreadNotificationsCubit(
          repo: repo,
          token: token,
        ); // cubit
        cubit.refresh(); // fetch unread at start
        return cubit; // provide to subtree
      },
      child: Scaffold(
        body: SafeArea(
          top: true,
          bottom: false, // insets
          child: BlocBuilder<UserUnreadNotificationsCubit, UserUnreadState>(
            builder: (ctx, s) =>
                _buildContent(ctx, liveUnread: s.count), // use live count
          ),
        ),
      ),
    );
  }
}

// ====== SEE-ALL pages with your AppSearchAppBar (unchanged) ======

class _AllInterestsPage extends StatefulWidget {
  final GetInterestBasedItems getInterestBased; // UC
  final String token; // token
  final int userId; // id
  final String? currencyFallback; // fallback
  final Future<String?> Function()? getCurrencyCode; // currency getter
  final String? imageBaseUrl; // image base

  const _AllInterestsPage({
    required this.getInterestBased,
    required this.token,
    required this.userId,
    this.currencyFallback,
    this.getCurrencyCode,
    this.imageBaseUrl,
  });

  @override
  State<_AllInterestsPage> createState() => _AllInterestsPageState();
}

class _AllInterestsPageState extends State<_AllInterestsPage> {
  String _query = ''; // local search query

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // i18n

    return Scaffold(
      appBar: AppSearchAppBar(
        hint: t.searchPlaceholder, // search hint
        initialQuery: _query, // initial text
        onQueryChanged: (q) => setState(() => _query = q.trim()), // update
        onClear: () => setState(() => _query = ''), // clear
        debounceMs: 250, // debounce typing
        showBack: true, // back button
      ),
      body: InterestSection(
        title: t.homeInterestBasedTitle, // title
        usecase: widget.getInterestBased, // UC
        token: widget.token, // token
        userId: widget.userId, // id
        currencyCode: widget.currencyFallback, // fallback
        getCurrencyCode: widget.getCurrencyCode, // getter
        imageBaseUrl: widget.imageBaseUrl, // base
        maxItems: null, // show all
        searchQuery: _query, // filter by query
        standalone: true, // full screen
        onShowAll: null, // hide see-all
      ),
    );
  }
}

class _AllExplorePage extends StatefulWidget {
  final GetUpcomingGuestItems getUpcomingGuest; // UC
  final String? currencyFallback; // fallback
  final Future<String?> Function()? getCurrencyCode; // currency getter
  final String? imageBaseUrl; // image base

  const _AllExplorePage({
    required this.getUpcomingGuest,
    this.currencyFallback,
    this.getCurrencyCode,
    this.imageBaseUrl,
  });

  @override
  State<_AllExplorePage> createState() => _AllExplorePageState();
}

class _AllExplorePageState extends State<_AllExplorePage> {
  String _query = ''; // local search query

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // i18n

    return Scaffold(
      appBar: AppSearchAppBar(
        hint: t.searchPlaceholder, // hint
        initialQuery: _query, // initial text
        onQueryChanged: (q) => setState(() => _query = q.trim()), // update
        onClear: () => setState(() => _query = ''), // clear
        debounceMs: 250, // debounce
        showBack: true, // back btn
      ),
      body: ExploreSection(
        title: t.homeExploreActivities, // title
        usecase: widget.getUpcomingGuest, // UC
        currencyCode: widget.currencyFallback, // fallback
        getCurrencyCode: widget.getCurrencyCode, // getter
        imageBaseUrl: widget.imageBaseUrl, // base
        maxItems: null, // all
        searchQuery: _query, // filter
        standalone: true, // full page
        onShowAll: null, // hide see-all
      ),
    );
  }
}
