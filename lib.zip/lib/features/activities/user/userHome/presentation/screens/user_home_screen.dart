// Flutter 3.35.x — Tight header, dynamic currency (with fallback), absolute image URLs.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hobby_sphere/app/router/router.dart';
import 'package:hobby_sphere/features/activities/user/userNotification/data/repositories/user_notification_repository_impl.dart';
import 'package:hobby_sphere/features/activities/user/userNotification/data/services/user_notification_service.dart';
import 'package:hobby_sphere/features/activities/user/userNotification/presentation/bloc/user_unread_cubit.dart';
import 'package:hobby_sphere/l10n/app_localizations.dart';
import 'package:hobby_sphere/core/network/globals.dart' as g;

// Sections
import 'package:hobby_sphere/features/activities/user/userHome/presentation/widgets/interest_section.dart';
import 'package:hobby_sphere/features/activities/user/userHome/presentation/widgets/explore_section.dart';
import 'package:hobby_sphere/features/activities/common/presentation/widgets/activity_types_section.dart';
import 'package:hobby_sphere/features/activities/common/presentation/screens/activity_types_all_screen.dart';
import 'package:hobby_sphere/features/activities/common/presentation/screens/activities_by_type_screen.dart';

// Usecases
import 'package:hobby_sphere/features/activities/user/userHome/domain/usecases/get_interest_based_items.dart';
import 'package:hobby_sphere/features/activities/user/userHome/domain/usecases/get_upcoming_guest_items.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_item_types.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_items_by_type.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_current_currency.dart';

// Data layer for currency
import 'package:hobby_sphere/features/activities/common/data/repositories/currency_repository_impl.dart';
import 'package:hobby_sphere/features/activities/common/data/services/currency_service.dart';

// Header
import 'package:hobby_sphere/features/activities/user/common/presentation/widgets/home_header.dart';

// Your search bar
import 'package:hobby_sphere/shared/widgets/app_search_bar.dart';

class UserHomeScreen extends StatelessWidget {
  /// Show these in the header (never username).
  final String? firstName;
  final String? lastName;

  final String? avatarUrl;
  final int unreadCount;

  final String token;
  final int userId;

  final GetInterestBasedItems getInterestBased;
  final GetUpcomingGuestItems getUpcomingGuest;
  final GetItemTypes getItemTypes;
  final GetItemsByType getItemsByType;

  /// Optional fallback currency code if [getCurrencyCode] is null or pending.
  final String? currencyFallback;

  /// Provide a future that returns the active currency (e.g. 'CAD', 'USD', ...).
  final Future<String?> Function()? getCurrencyCode;

  const UserHomeScreen({
    super.key,
    this.firstName,
    this.lastName,
    this.avatarUrl,
    this.unreadCount = 0,
    required this.token,
    required this.userId,
    required this.getInterestBased,
    required this.getUpcomingGuest,
    required this.getItemTypes,
    required this.getItemsByType,
    this.currencyFallback,
    this.getCurrencyCode,
  });

  String _serverRoot() {
    final base = (g.appServerRoot ?? '');
    return base.replaceFirst(RegExp(r'/api/?$'), '');
  }

  // Go to activity-details screen                                   // comment
  void _goToDetails(BuildContext context, int itemId, String imageBaseUrl) {
    // Ensure token has "Bearer " prefix if required by backend       // comment
    final bearer = token.startsWith('Bearer ') ? token : 'Bearer $token';

    // Push named route with strongly-typed args                      // comment
    Navigator.of(context).pushNamed(
      Routes.userActivityDetail, // route name
      arguments: UserActivityDetailRouteArgs(
        // args bag
        itemId: itemId, // which item
        token: bearer.isNotEmpty ? bearer : null, // auth or guest
        currencyCode: currencyFallback, // show prices
        imageBaseUrl: imageBaseUrl, // build absolute img urls
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final serverRoot = _serverRoot();

    final getCurrencyCodeFn =
        getCurrencyCode ??
        (() async {
          final usecase = GetCurrentCurrency(
            CurrencyRepositoryImpl(CurrencyService()),
          );
          final cur = await usecase(token);
          return cur.code; // e.g. "CAD"
        });

    return BlocProvider<UserUnreadNotificationsCubit>(
      create: (_) {
        final repo = UserNotificationRepositoryImpl(UserNotificationService());
        final cubit = UserUnreadNotificationsCubit(repo: repo, token: token);
        // kick off initial fetch
        cubit.refresh();
        return cubit;
      },
      child: Scaffold(
        body: SafeArea(
          top: true,
          bottom: false,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              BlocBuilder<UserUnreadNotificationsCubit, UserUnreadState>(
                builder: (context, s) {
                  return HomeHeader(
                    firstName: firstName,
                    lastName: lastName,
                    avatarUrl: avatarUrl,
                    unreadCount: s.count, // ✅ live count from cubit
                    margin: EdgeInsets.zero,
                    padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
                    radius: 10,
                    onBellTap: () {
                      // navigate to user notifications
                      Navigator.of(context)
                          .pushNamed(
                            Routes.userNotifications,
                            arguments: UserNotificationsRouteArgs(token: token),
                          )
                          .then((_) {
                            // refresh when returning from the screen
                            context
                                .read<UserUnreadNotificationsCubit>()
                                .refresh();
                          });
                    },
                  );
                },
              ),

              const Divider(height: 1),

              // ==== Interest-based (HOME: 4) ====
              if (token.trim().isNotEmpty && userId > 0)
                InterestSection(
                  title: t.homeInterestBasedTitle,
                  showAllLabel: t.homeSeeAll,
                  usecase: getInterestBased,
                  token: token,
                  userId: userId,
                  currencyCode: currencyFallback,
                  getCurrencyCode: getCurrencyCodeFn,
                  imageBaseUrl: serverRoot,
                  maxItems: 4,
                  standalone: false,
                  onItemTap: (id) {},
                  onShowAll: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => _AllInterestsPage(
                          getInterestBased: getInterestBased,
                          token: token,
                          userId: userId,
                          currencyFallback: currencyFallback,
                          getCurrencyCode: getCurrencyCodeFn,
                          imageBaseUrl: serverRoot,
                        ),
                      ),
                    );
                  },
                ),

              const SizedBox(height: 6),

              // ==== Categories ====
              ActivityTypesSection(
                getTypes: getItemTypes,
                getItemsByType: getItemsByType,
                token: token,
                onlyWithActivities: true,
                onTypeTap: (id, name) {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ActivitiesByTypeScreen(
                        typeId: id,
                        typeName: name,
                        getItemsByType: getItemsByType,
                        currencyCode: currencyFallback, // optional fallback
                        getCurrencyCode: getCurrencyCodeFn,
                        imageBaseUrl: serverRoot,
                      ),
                    ),
                  );
                },
                onSeeAll: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ActivityTypesAllScreen(
                        getTypes: getItemTypes,
                        getItemsByType: getItemsByType,
                        token: token,
                        onTypeTap: (id, name) {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => ActivitiesByTypeScreen(
                                typeId: id,
                                typeName: name,
                                getItemsByType: getItemsByType,
                                currencyCode: currencyFallback,
                                imageBaseUrl: serverRoot,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 6),

              // ==== Explore (HOME: 6) ====
              ExploreSection(
                title: t.homeExploreActivities,
                showAllLabel: t.homeSeeAll,
                usecase: getUpcomingGuest,
                currencyCode: currencyFallback,
                getCurrencyCode: getCurrencyCodeFn,
                imageBaseUrl: serverRoot,
                maxItems: 6,
                standalone: false,
                onItemTap: (id) {},
                onShowAll: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => _AllExplorePage(
                        getUpcomingGuest: getUpcomingGuest,
                        currencyFallback: currencyFallback,
                        getCurrencyCode: getCurrencyCodeFn,
                        imageBaseUrl: serverRoot,
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

// ===== SEE-ALL pages with your AppSearchAppBar =====

class _AllInterestsPage extends StatefulWidget {
  final GetInterestBasedItems getInterestBased;
  final String token;
  final int userId;

  final String? currencyFallback;
  final Future<String?> Function()? getCurrencyCode;
  final String? imageBaseUrl;

  const _AllInterestsPage({
    required this.getInterestBased,
    required this.token,
    required this.userId,
    this.currencyFallback,
    this.getCurrencyCode,
    this.imageBaseUrl,
  });

  @override
  State<_AllInterestsPage> createState() => _AllInterestsPageState();
}

class _AllInterestsPageState extends State<_AllInterestsPage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppSearchAppBar(
        hint: t.searchPlaceholder,
        initialQuery: _query,
        onQueryChanged: (q) => setState(() => _query = q.trim()),
        onClear: () => setState(() => _query = ''),
        debounceMs: 250,
        showBack: true,
      ),
      body: InterestSection(
        title: t.homeInterestBasedTitle,
        usecase: widget.getInterestBased,
        token: widget.token,
        userId: widget.userId,
        currencyCode: widget.currencyFallback,
        getCurrencyCode: widget.getCurrencyCode,
        imageBaseUrl: widget.imageBaseUrl,
        maxItems: null,
        searchQuery: _query,
        standalone: true,
        onShowAll: null,
      ),
    );
  }
}

class _AllExplorePage extends StatefulWidget {
  final GetUpcomingGuestItems getUpcomingGuest;

  final String? currencyFallback;
  final Future<String?> Function()? getCurrencyCode;
  final String? imageBaseUrl;

  const _AllExplorePage({
    required this.getUpcomingGuest,
    this.currencyFallback,
    this.getCurrencyCode,
    this.imageBaseUrl,
  });

  @override
  State<_AllExplorePage> createState() => _AllExplorePageState();
}

class _AllExplorePageState extends State<_AllExplorePage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppSearchAppBar(
        hint: t.searchPlaceholder,
        initialQuery: _query,
        onQueryChanged: (q) => setState(() => _query = q.trim()),
        onClear: () => setState(() => _query = ''),
        debounceMs: 250,
        showBack: true,
      ),
      body: ExploreSection(
        title: t.homeExploreActivities,
        usecase: widget.getUpcomingGuest,
        currencyCode: widget.currencyFallback,
        getCurrencyCode: widget.getCurrencyCode,
        imageBaseUrl: widget.imageBaseUrl,
        maxItems: null,
        searchQuery: _query,
        standalone: true,
        onShowAll: null,
      ),
    );
  }
}
