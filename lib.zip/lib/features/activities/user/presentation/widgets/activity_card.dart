// Flutter 3.35.x
// Reusable, pressable Activity Card for User
import 'package:flutter/material.dart'; // ui
import 'package:intl/intl.dart'; // date format
import 'package:hobby_sphere/shared/theme/app_theme.dart'; // AppColors.muted

// Data holder – only id + title required
class ActivityCardData {
  final int id; // item id
  final String title; // item name
  final DateTime? start; // start time
  final num? price; // price
  final String? imageUrl; // image url
  final String? location; // location

  const ActivityCardData({
    required this.id, // require id
    required this.title, // require title
    this.start, // optional
    this.price, // optional
    this.imageUrl, // optional
    this.location, // optional
  });
}

// Layout variants for reuse
enum ActivityCardVariant { square, horizontal, compact } // 3 layouts

class ActivityCard extends StatelessWidget {
  final ActivityCardData item; // data
  final ActivityCardVariant variant; // layout
  final VoidCallback? onPressed; // tap action
  final String? currencyCode; // "USD"/"EUR"
  final bool isSingle; // width hint
  final double? width; // fixed width
  final EdgeInsets margin; // outer margin
  final EdgeInsets padding; // inner padding

  const ActivityCard({
    super.key,
    required this.item, // inject data
    this.variant = ActivityCardVariant.square, // default layout
    this.onPressed, // tap callback
    this.currencyCode, // currency code
    this.isSingle = false, // grid hint
    this.width, // optional width
    this.margin = const EdgeInsets.only(bottom: 12), // default gap
    this.padding = const EdgeInsets.all(12), // default pad
  });

  String _symbolFor(String? code) {
    // map code->symbol
    final c = (code ?? '').trim().toUpperCase(); // normalize
    switch (c) {
      case 'USD':
        return r'$'; // dollar
      case 'EUR':
        return '€'; // euro
      case 'CAD':
        return 'C\$'; // CAD
      case 'LBP':
      case 'L.L':
        return 'ل.ل'; // Lebanese pound
      default:
        return c; // fallback
    }
  }

  String _formatPrice(num? p, String? code) {
    // price text
    if (p == null) return ''; // no price
    final sym = _symbolFor(code); // symbol
    final v = p % 1 == 0 ? p.toInt().toString() : p.toStringAsFixed(2); // fmt
    return sym.isEmpty ? v : '$sym$v'; // join
  }

  String _formatDate(DateTime? dt) {
    // date text
    if (dt == null) return ''; // no date
    return '${DateFormat('EEE, d MMM').format(dt)} · ${DateFormat('HH:mm').format(dt)}'; // fmt
  }

  Widget _buildImage({
    // image builder
    required String? url,
    double? width,
    double? height,
    BoxFit fit = BoxFit.cover,
    BorderRadius? radius,
  }) {
    return ClipRRect(
      borderRadius: radius ?? BorderRadius.circular(12), // round
      child: Image.network(
        (url ?? '').trim(), // url or empty
        width: width,
        height: height,
        fit: fit, // sizing
        errorBuilder: (_, __, ___) => Container(
          // fallback
          width: width,
          height: height,
          color: Colors.black12,
          alignment: Alignment.center,
          child: const Icon(Icons.image_not_supported_outlined),
        ),
        loadingBuilder: (ctx, child, progress) {
          // loader
          if (progress == null) return child; // done
          return Container(
            width: width,
            height: height,
            color: Colors.black12,
            alignment: Alignment.center,
            child: const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          );
        },
      ),
    );
  }

  Widget _info(BuildContext context) {
    // info block
    final tt = Theme.of(context).textTheme; // text theme
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start, // left align
      mainAxisSize: MainAxisSize.min, // hug
      children: [
        Text(
          item.title.isEmpty ? '—' : item.title, // title
          maxLines: 1,
          overflow: TextOverflow.ellipsis, // trim
          style: tt.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 4), // gap
        if (item.start != null) // date row
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.calendar_today_outlined,
                size: 12,
                color: AppColors.muted,
              ),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                  _formatDate(item.start), // date text
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tt.bodyMedium?.copyWith(
                    fontSize: 12,
                    color: AppColors.muted,
                  ),
                ),
              ),
            ],
          ),
        if (item.price != null) ...[
          // price text
          const SizedBox(height: 6),
          Text(
            _formatPrice(item.price, currencyCode), // "$25" etc
            style: tt.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme; // colors
    final radius = BorderRadius.circular(16); // radius

    void tap() => onPressed?.call(); // tap handler

    switch (variant) {
      case ActivityCardVariant.compact: // compact card
        return Container(
          margin: margin,
          width: width,
          child: Material(
            color: cs.surface,
            borderRadius: radius,
            elevation: 2,
            child: InkWell(
              onTap: tap,
              borderRadius: radius,
              child: Padding(
                padding: padding,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildImage(
                      url: item.imageUrl,
                      width: double.infinity,
                      height: 120,
                      radius: BorderRadius.circular(12),
                    ),
                    const SizedBox(height: 8),
                    _info(context),
                  ],
                ),
              ),
            ),
          ),
        );

      case ActivityCardVariant.horizontal: // list row
        return Container(
          margin: margin,
          width: width,
          child: Material(
            color: cs.surface,
            borderRadius: radius,
            elevation: 3,
            child: InkWell(
              onTap: tap,
              borderRadius: radius,
              child: Padding(
                padding: padding,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildImage(
                      url: item.imageUrl,
                      width: 72,
                      height: 72,
                      radius: BorderRadius.circular(12),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: _info(context)),
                  ],
                ),
              ),
            ),
          ),
        );

      case ActivityCardVariant.square: // square bg
        return Container(
          margin: margin,
          width: width ?? (isSingle ? 220 : null),
          child: AspectRatio(
            aspectRatio: 1,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: tap,
                borderRadius: radius,
                child: ClipRRect(
                  borderRadius: radius,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      _buildImage(
                        url: item.imageUrl,
                        fit: BoxFit.cover,
                        radius: BorderRadius.zero,
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          margin: const EdgeInsets.all(10),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: cs.surface,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(.12),
                                blurRadius: 12,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: _info(context),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
    }
  }
}
