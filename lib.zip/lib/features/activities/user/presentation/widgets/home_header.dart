// Flutter 3.35.x
// Home header card: avatar + name + subtitle + shared notification badge.

import 'package:flutter/material.dart'; // UI
import 'package:hobby_sphere/l10n/app_localizations.dart'; // i18n
import 'package:hobby_sphere/shared/widgets/notification_badge.dart'; // shared badge
import 'package:hobby_sphere/shared/theme/app_theme.dart'; // AppColors.muted

class HomeHeader extends StatelessWidget {
  final String displayName; // user name
  final String? subtitle; // optional subtitle (i18n if null)
  final String? avatarUrl; // optional avatar url
  final int unreadCount; // unread notifications number
  final VoidCallback? onBellTap; // open notifications

  const HomeHeader({
    super.key,
    required this.displayName, // must have a name
    this.subtitle, // optional line under name
    this.avatarUrl, // optional image
    this.unreadCount = 0, // default 0 (hide badge)
    this.onBellTap, // optional tap
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context); // theme reference
    final cs = theme.colorScheme; // ColorScheme
    final text = theme.textTheme; // TextTheme
    final t = AppLocalizations.of(context)!; // i18n

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 8), // outside spacing
      padding: const EdgeInsets.all(12), // inside spacing
      decoration: BoxDecoration(
        color: cs.surface, // card bg from theme
        borderRadius: BorderRadius.circular(16), // rounded card
        boxShadow: [
          // soft elevation
          BoxShadow(
            color: Colors.black.withOpacity(0.06), // light shadow
            blurRadius: 12, // blur amount
            offset: const Offset(0, 4), // move down
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22, // avatar size
            backgroundColor: cs.surfaceVariant, // fallback bg
            backgroundImage: (avatarUrl != null && avatarUrl!.isNotEmpty)
                ? NetworkImage(avatarUrl!) // load network image
                : null, // else show icon
            child: (avatarUrl == null || avatarUrl!.isEmpty)
                ? Icon(
                    Icons.person,
                    color: cs.onSurfaceVariant,
                  ) // fallback icon
                : null, // hide icon if image exists
          ),

          const SizedBox(width: 12), // space between avatar and text

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start, // left aligned texts
              mainAxisSize: MainAxisSize.min, // hug content
              children: [
                Text(
                  displayName, // main title (name)
                  maxLines: 1, // single line
                  overflow: TextOverflow.ellipsis, // trim long names
                  style: text.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600, // semi-bold
                  ),
                ),
                const SizedBox(height: 2), // small gap
                Text(
                  subtitle ?? t.homeFindActivity, // subtitle or default
                  maxLines: 1, // single line
                  overflow: TextOverflow.ellipsis, // trim long text
                  style: text.bodyMedium?.copyWith(
                    fontSize: 13, // slightly smaller
                    color: AppColors.muted, // your muted gray
                    height: 1.2, // compact line height
                  ),
                ),
              ],
            ),
          ),

          // ✅ Shared badge (no Business change)
          NotificationBadge(
            count: unreadCount, // unread number (0 hides)
            onTap: onBellTap, // open notifications
            iconSize: 26, // match your style
            tooltip: t.notifications, // i18n tooltip text
            // colors default to theme (primary/error), so no need to override
          ),
        ],
      ),
    );
  }
}
