// Flutter 3.35.x
// Business Home screen. It benefits from Splash preloading 'biz.home'
// (upcoming + KPIs) so it opens instantly with hot caches + precached images.

import 'dart:async'; // Completer for pull-to-refresh
import 'package:flutter/material.dart'; // UI
import 'package:flutter_bloc/flutter_bloc.dart'; // BlocProvider/Consumer
import 'package:hobby_sphere/app/router/router.dart'; // routes + args
import 'package:hobby_sphere/core/network/globals.dart' as g; // server root
import 'package:hobby_sphere/features/activities/Business/businessHome/presentation/widgets/welcome_section.dart'; // header welcome
import 'package:hobby_sphere/features/activities/Business/businessNotification/presentation/bloc/business_notification_bloc.dart'; // notif bloc
import 'package:hobby_sphere/features/activities/Business/businessNotification/presentation/bloc/business_notification_event.dart'; // notif events

// Domain UCs
import 'package:hobby_sphere/features/activities/Business/common/domain/usecases/get_business_activities.dart';
import 'package:hobby_sphere/features/activities/Business/common/domain/usecases/get_business_activity_by_id.dart';
import 'package:hobby_sphere/features/activities/Business/common/domain/usecases/delete_business_activity.dart';

// Data layer
import 'package:hobby_sphere/features/activities/Business/common/data/repositories/business_activity_repository_impl.dart';
import 'package:hobby_sphere/features/activities/Business/common/data/services/business_activity_service.dart';

// UI widgets (cards, header)
import 'package:hobby_sphere/features/activities/Business/businessHome/presentation/widgets/header.dart';
import 'package:hobby_sphere/shared/widgets/BusinessListItemCard.dart'; // list card

import 'package:hobby_sphere/shared/widgets/top_toast.dart'; // toast
import 'package:hobby_sphere/l10n/app_localizations.dart'; // l10n

// Home BLoC for business
import '../bloc/business_home_bloc.dart';
import '../bloc/business_home_event.dart';
import '../bloc/business_home_state.dart';

class BusinessHomeScreen extends StatelessWidget {
  // Auth + identity
  final String token; // JWT string
  final int businessId; // business id

  // Handlers
  final void Function(BuildContext context, int businessId) onCreate; // create
  final Widget? bottomBar; // optional bottom bar

  const BusinessHomeScreen({
    super.key,
    required this.token,
    required this.businessId,
    required this.onCreate,
    this.bottomBar,
  });

  // Helper to get server root without /api.
  String _serverRoot() {
    final base = (g.appServerRoot ?? ''); // e.g., https://api.../api
    return base.replaceFirst(RegExp(r'/api/?$'), ''); // → https://api...
  }

  @override
  Widget build(BuildContext context) {
    // Build service/repo/UCs (you can inject via DI if you prefer).
    final service = BusinessActivityService(); // service
    final repo = BusinessActivityRepositoryImpl(service); // repo
    final getList = GetBusinessActivities(repo); // list UC
    final getOne = GetBusinessActivityById(repo); // detail UC
    final deleteOne = DeleteBusinessActivity(repo); // delete UC

    // Provide BusinessHomeBloc and start it immediately.
    return BlocProvider(
      create: (_) => BusinessHomeBloc(
        getList: getList, // UC list
        getOne: getOne, // UC get by id
        deleteOne: deleteOne, // UC delete
        token: token, // auth token
        businessId: businessId, // id
        optimisticDelete: false, // disable optimistic remove
      )..add(const BusinessHomeStarted()), // initial event
      child: _BusinessHomeView(
        onCreate: onCreate, // forward handler
        serverRoot: _serverRoot(), // compute server root once
        bottomBar: bottomBar, // optional bar
        businessId: businessId, // id
        token: token, // token
      ),
    );
  }
}

class _BusinessHomeView extends StatelessWidget {
  final void Function(BuildContext context, int businessId)
  onCreate; // create handler
  final String serverRoot; // base url without /api
  final Widget? bottomBar; // bottom bar
  final int businessId; // id
  final String token; // jwt

  const _BusinessHomeView({
    required this.onCreate,
    required this.serverRoot,
    this.bottomBar,
    required this.businessId,
    required this.token,
  });

  // Quick toast helper to show success/error banners.
  void _toast(BuildContext context, String msg, {bool error = false}) {
    final rootCtx = Navigator.of(context, rootNavigator: true).context; // root
    showTopToast(
      rootCtx, // overlay root context
      msg, // text
      type: error ? ToastType.error : ToastType.success, // style
      haptics: true, // vibration
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!; // i18n
    final cs = Theme.of(context).colorScheme; // theme colors

    // Build header with welcome, notifications badge, and create button.
    final header = Column(
      crossAxisAlignment: CrossAxisAlignment.start, // align left
      children: [
        WelcomeSection(
          token: context.read<BusinessHomeBloc>().token, // pass token
          onOpenNotifications: () async {
            // Open notifications page.
            await Navigator.pushNamed(
              context, // nav ctx
              Routes.businessNotifications, // route name
              arguments: BusinessNotificationsRouteArgs(
                token: token, // jwt
                businessId: businessId, // id
              ),
            );
            // After return, refresh badge (and optionally list).
            final notifBloc = context.read<BusinessNotificationBloc>(); // bloc
            notifBloc
              ..add(LoadBusinessNotifications()) // refresh list
              ..add(LoadUnreadCount(token)); // refresh count
          },
          onOpenCreateActivity: () => onCreate(context, businessId), // create
        ),
        const HeaderWithBadge(), // header with notification badge
      ],
    );

    // Listen for success/error messages from bloc and show top toasts.
    return BlocConsumer<BusinessHomeBloc, BusinessHomeState>(
      listenWhen: (prev, curr) =>
          prev.message != curr.message ||
          prev.error != curr.error, // only when changed
      listener: (context, state) {
        if (state.message != null && state.message!.isNotEmpty) {
          _toast(context, state.message!); // success toast
          context.read<BusinessHomeBloc>().add(
            const BusinessHomeFeedbackCleared(),
          ); // clear msg
        } else if (state.error != null && state.error!.isNotEmpty) {
          _toast(context, state.error!, error: true); // error toast
          context.read<BusinessHomeBloc>().add(
            const BusinessHomeFeedbackCleared(),
          ); // clear err
        }
      },
      builder: (context, state) {
        return Scaffold(
          backgroundColor: cs.background, // scaffold bg
          body: RefreshIndicator(
            // Pull-to-refresh → triggers bloc refresh.
            onRefresh: () {
              final c = Completer<void>(); // completer for indicator
              context.read<BusinessHomeBloc>().add(
                BusinessHomeRefreshed(ack: c),
              ); // event
              return c.future; // complete from bloc side
            },
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(child: header), // header sliver
                // When there are no items and we are not loading → empty state.
                if (state.items.isEmpty && !state.loading)
                  SliverFillRemaining(
                    hasScrollBody: false, // center vertically
                    child: Center(
                      child: Text(
                        t.activitiesEmpty, // localized "empty"
                        style: Theme.of(context).textTheme.bodyMedium, // style
                      ),
                    ),
                  )
                else
                  // Normal list of business activities.
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (ctx, index) {
                        final a = state.items[index]; // item

                        // Skip terminated items visually.
                        if (a.status.toLowerCase() == 'terminated') {
                          return const SizedBox(); // hide
                        }

                        // Card with actions (view/edit/delete).
                        return BusinessListItemCard(
                          id: '${a.id}', // id as string
                          title: a.name, // title
                          startDate: a.startDate, // date
                          location: a.location, // location
                          imageUrl: a.imageUrl, // thumbnail url
                          onView: () async {
                            // Open details page; if returns true → reload list.
                            final result = await Navigator.pushNamed(
                              context, // ctx
                              Routes.businessActivityDetails, // route
                              arguments: BusinessActivityDetailsRouteArgs(
                                token: token, // jwt
                                activityId: a.id, // id
                              ),
                            );
                            if (result == true) {
                              context.read<BusinessHomeBloc>().add(
                                const BusinessHomeStarted(),
                              ); // reload
                            }
                          },
                          onEdit: () {
                            // Open edit screen (use root navigator to avoid nested modals).
                            final rootCtx = Navigator.of(
                              context,
                              rootNavigator: true,
                            ).context; // root
                            Navigator.pushNamed(
                              rootCtx, // root context
                              Routes.editBusinessActivity, // route
                              arguments: EditActivityRouteArgs(
                                itemId: a.id, // id
                                businessId: businessId, // biz id
                              ),
                            );
                          },
                          onDelete: () =>
                              _confirmDelete(ctx, a.id), // confirm then delete
                        );
                      },
                      childCount: state.items.length, // list size
                    ),
                  ),
              ],
            ),
          ),
          bottomNavigationBar: bottomBar, // optional bottom bar
        );
      },
    );
  }

  // Confirmation dialog before deletion.
  Future<void> _confirmDelete(BuildContext context, int id) async {
    final ok = await showDialog<bool>(
      context: context, // dialog ctx
      builder: (ctx) => AlertDialog(
        title: const Text('Delete?'), // title
        content: const Text(
          'Are you sure you want to delete this activity?',
        ), // message
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false), // cancel
            child: const Text('Cancel'), // text
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true), // confirm
            child: const Text('Delete'), // text
          ),
        ],
      ),
    );
    if (ok == true) {
      // Send delete request via bloc.
      context.read<BusinessHomeBloc>().add(
        BusinessHomeDeleteRequested(id),
      ); // event
    }
  }
}
