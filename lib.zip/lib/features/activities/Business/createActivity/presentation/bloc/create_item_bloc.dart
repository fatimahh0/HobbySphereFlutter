// Flutter 3.35.x — CreateItemBloc
// This version adds a fallback: if no new file is picked but we have old imageUrl,
// we download that image and send it as a multipart file so the backend keeps it.

import 'dart:io'; // File + temp dir
import 'package:flutter_bloc/flutter_bloc.dart'; // Bloc
import 'package:http/http.dart' as http; // Simple HTTP download
import 'package:hobby_sphere/core/network/globals.dart'
    as g; // serverRootNoApi()

import 'package:hobby_sphere/features/activities/common/domain/usecases/get_current_currency.dart';
import 'package:hobby_sphere/features/activities/common/domain/usecases/get_item_types.dart';
import 'package:hobby_sphere/services/token_store.dart';

import '../../domain/usecases/create_item.dart';
import '../../domain/entities/create_item_request.dart';

import 'create_item_event.dart';
import 'create_item_state.dart';

class CreateItemBloc extends Bloc<CreateItemEvent, CreateItemState> {
  final CreateItem createItem; // Use case to create item
  final GetItemTypes getItemTypes; // Loads types
  final GetCurrentCurrency getCurrentCurrency; // Loads currency

  CreateItemBloc({
    required this.createItem, // Inject use case
    required this.getItemTypes, // Inject types loader
    required this.getCurrentCurrency, // Inject currency loader
    required int businessId, // Business owner id
  }) : super(CreateItemState(businessId: businessId)) {
    // Initial state
    on<CreateItemBootstrap>(_onBootstrap); // Load dropdowns + currency
    on<CreateItemNameChanged>((e, emit) => emit(state.copyWith(name: e.name)));
    on<CreateItemTypeChanged>(
      (e, emit) => emit(state.copyWith(itemTypeId: e.typeId)),
    );
    on<CreateItemDescriptionChanged>(
      (e, emit) => emit(state.copyWith(description: e.description)),
    );
    on<CreateItemLocationPicked>(
      (e, emit) =>
          emit(state.copyWith(address: e.address, lat: e.lat, lng: e.lng)),
    );
    on<CreateItemMaxChanged>(
      (e, emit) => emit(state.copyWith(maxParticipants: e.max)),
    );
    on<CreateItemPriceChanged>(
      (e, emit) => emit(state.copyWith(price: e.price)),
    );
    on<CreateItemStartChanged>((e, emit) => emit(state.copyWith(start: e.dt)));
    on<CreateItemEndChanged>((e, emit) => emit(state.copyWith(end: e.dt)));

    // Keep old URL when reopening an item (no file picked yet)
    on<CreateItemImageUrlRetained>(
      (e, emit) => emit(
        state.copyWith(imageUrl: e.imageUrl, error: null, success: null),
      ),
    );

    // If a new file is picked, prefer it and clear the URL
    on<CreateItemImagePicked>((e, emit) {
      emit(
        state.copyWith(
          image: e.image, // Save picked file (can be null)
          imageUrl: e.image != null
              ? null
              : state.imageUrl, // Clear URL only if file exists
        ),
      );
    });

    on<CreateItemSubmitPressed>(_onSubmit); // Submit logic
  }

  Future<void> _onBootstrap(
    CreateItemBootstrap event,
    Emitter<CreateItemState> emit,
  ) async {
    // Load item types and current currency
    emit(state.copyWith(loading: true, error: null, success: null));
    try {
      final auth = await TokenStore.read(); // Read saved token
      final token = auth.token ?? ''; // JWT string
      final types = await getItemTypes(token); // Fetch item types
      final currency = await getCurrentCurrency(token); // Fetch currency
      emit(state.copyWith(loading: false, types: types, currency: currency));
    } catch (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    }
  }

  // Download existing image to a temp file so we can re-upload it as "image"
  Future<File> _downloadToTemp(String absoluteUrl) async {
    final uri = Uri.parse(absoluteUrl); // Parse URL
    final res = await http.get(uri); // GET bytes
    if (res.statusCode != 200 || res.bodyBytes.isEmpty) {
      throw Exception('Failed to download image'); // Fail fast
    }
    final name = uri.pathSegments.isNotEmpty
        ? uri.pathSegments.last
        : 'reopen_${DateTime.now().millisecondsSinceEpoch}.jpg'; // File name
    final file = File('${Directory.systemTemp.path}/$name'); // Temp path
    await file.writeAsBytes(res.bodyBytes); // Save bytes to file
    return file; // Return file
  }

  Future<void> _onSubmit(
    CreateItemSubmitPressed event,
    Emitter<CreateItemState> emit,
  ) async {
    // Basic form validations
    if (!state.ready) {
      emit(state.copyWith(error: 'Please fill all required fields.'));
      return;
    }
    if (state.start != null &&
        state.end != null &&
        !state.end!.isAfter(state.start!)) {
      emit(state.copyWith(error: 'End must be after Start.'));
      return;
    }

    // Keep URL from state (if any)
    String? normalizedUrl = state.imageUrl;

    // If URL is absolute to our server, strip only the server root (keep leading '/')
    if (normalizedUrl != null && normalizedUrl.isNotEmpty) {
      final base = g.serverRootNoApi(); // e.g., http://3.96.140.126:8080
      if (base.isNotEmpty && normalizedUrl.startsWith(base)) {
        normalizedUrl = normalizedUrl.substring(base.length); // Make relative
      }
      if (!normalizedUrl.startsWith('/')) {
        normalizedUrl = '/$normalizedUrl'; // Ensure leading slash for server
      }
    }

    // Preferred file to send
    File? imageFile = state.image; // New file (if user picked one)

    // 🔥 Fallback: if no new file but we have an old URL, download + reupload it as a file.
    if (imageFile == null && (normalizedUrl?.isNotEmpty ?? false)) {
      final abs = normalizedUrl!.startsWith('http')
          ? normalizedUrl // Already absolute
          : '${g.serverRootNoApi()}$normalizedUrl'; // Build absolute from server root
      try {
        imageFile = await _downloadToTemp(abs); // Download to temp
        normalizedUrl = null; // We will send as file, not URL
      } catch (e) {
        // If download fails, we still try sending the URL (backend may accept it).
        // Also log for debugging.
        // ignore: avoid_print
        print('fallback download failed: $e');
      }
    }

    emit(state.copyWith(loading: true, error: null, success: null)); // Busy
    try {
      final auth = await TokenStore.read(); // Read token
      final token = auth.token ?? ''; // JWT

      final now = DateTime.now(); // Compute status
      final computedStatus = (state.start != null && state.start!.isAfter(now))
          ? 'Upcoming'
          : 'Active';

      // Build and send request (file wins; URL only if file is null)
      final msg = await createItem(
        token: token,
        req: CreateItemRequest(
          itemName: state.name, // Name
          itemTypeId: state.itemTypeId!, // Type id
          description: state.description, // Description
          location: state.address, // Address
          latitude: state.lat!, // Lat
          longitude: state.lng!, // Lng
          maxParticipants: state.maxParticipants!, // Capacity
          price: state.price!, // Price
          startDatetime: state.start!, // Start
          endDatetime: state.end!, // End
          status: computedStatus, // Status
          businessId: state.businessId!, // Business id
          image: imageFile, // ✅ Always send a real file if we have one
          imageUrl: normalizedUrl, // Fallback only if no file
        ),
      );

      // Quick debug
      // ignore: avoid_print
      print('===== CREATE ITEM DEBUG =====');
      // ignore: avoid_print
      print('image file: ${imageFile?.path}');
      // ignore: avoid_print
      print('imageUrl: $normalizedUrl');
      // ignore: avoid_print
      print('=============================');

      emit(state.copyWith(loading: false, success: msg)); // Done
    } catch (e) {
      emit(state.copyWith(loading: false, error: e.toString())); // Error
    }
  }
}
