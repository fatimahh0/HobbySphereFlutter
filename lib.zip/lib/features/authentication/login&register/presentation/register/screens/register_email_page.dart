// ======================= register_email_page.dart — Flutter 3.35.x =======================
// Email registration flow + camera/gallery image picker for user photo, business logo, banner.
// Updated: uses go_router navigation on success (→ Shell if token exists, else → Login)
// and adds a friendly button on the final “Done” step.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:go_router/go_router.dart'; // ✅ go_router

// Usecases for interests
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/get_activity_types.dart';

// Bloc + events + states
import 'package:hobby_sphere/features/authentication/login&register/presentation/register/bloc/register_bloc.dart';
import 'package:hobby_sphere/features/authentication/login&register/presentation/register/bloc/register_event.dart';
import 'package:hobby_sphere/features/authentication/login&register/presentation/register/bloc/register_state.dart';

// Common small widgets
import 'package:hobby_sphere/features/authentication/login&register/presentation/login/widgets/password_input.dart';
import 'package:hobby_sphere/features/authentication/login&register/presentation/register/widgets/interests_grid.dart';
import 'package:hobby_sphere/features/authentication/login&register/presentation/login/widgets/role_selector.dart';
import '../widgets/login_link.dart';
import '../widgets/guidelines.dart';
import '../widgets/otp_boxes.dart';
import '../widgets/pill_field.dart';
import '../widgets/pick_box.dart';

// l10n + shared UI
import 'package:hobby_sphere/l10n/app_localizations.dart';
import 'package:hobby_sphere/shared/widgets/app_button.dart';
import 'package:hobby_sphere/shared/widgets/app_text_field.dart';
import 'package:hobby_sphere/shared/widgets/top_toast.dart';

// DI: services + repos
import 'package:hobby_sphere/features/authentication/login&register/data/services/registration_service.dart';
import 'package:hobby_sphere/features/authentication/login&register/data/repositories/registration_repository_impl.dart';
import 'package:hobby_sphere/features/authentication/login&register/data/repositories/interests_repository_impl.dart';

// Usecases: user
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/send_user_verification.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/verify_user_email_code.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/verify_user_phone_code.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/complete_user_profile.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/add_user_interests.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/resend_user_code.dart';

// Usecases: business
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/send_business_verification.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/verify_business_email_code.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/verify_business_phone_code.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/complete_business_profile.dart';
import 'package:hobby_sphere/features/authentication/login&register/domain/usecases/register/resend_business_code.dart';

// ✅ navigation + roles + globals for attaching token if the backend returns one
import 'package:hobby_sphere/app/router/router.dart'
    show Routes, ShellRouteArgs;
import 'package:hobby_sphere/core/constants/app_role.dart';
import 'package:hobby_sphere/core/network/globals.dart' as g;

// ======================= Public wrapper =======================

class RegisterEmailPage extends StatelessWidget {
  final RegistrationService service;
  final int initialRoleIndex;

  const RegisterEmailPage({
    super.key,
    required this.service,
    this.initialRoleIndex = 0,
  });

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
    final passedRoleIndex = (args is Map && args['roleIndex'] is int)
        ? (args['roleIndex'] as int)
        : initialRoleIndex;

    final regRepo = RegistrationRepositoryImpl(service);
    final interestsRepo = InterestsRepositoryImpl(service);

    return BlocProvider(
      create: (_) => RegisterBloc(
        // user
        sendUserVerification: SendUserVerification(regRepo),
        verifyUserEmail: VerifyUserEmailCode(regRepo),
        verifyUserPhone: VerifyUserPhoneCode(regRepo),
        completeUser: CompleteUserProfile(regRepo),
        addInterests: AddUserInterests(regRepo),
        resendUser: ResendUserCode(regRepo),
        // business
        sendBizVerification: SendBusinessVerification(regRepo),
        verifyBizEmail: VerifyBusinessEmailCode(regRepo),
        verifyBizPhone: VerifyBusinessPhoneCode(regRepo),
        completeBiz: CompleteBusinessProfile(regRepo),
        resendBiz: ResendBusinessCode(regRepo),
        // interests
        getActivityTypes: GetActivityTypes(interestsRepo),
      )..add(RegRoleChanged(passedRoleIndex)),
      child: const _RegisterEmailView(),
    );
  }
}

// ======================= Internal stateful view =======================

class _RegisterEmailView extends StatefulWidget {
  const _RegisterEmailView();
  @override
  State<_RegisterEmailView> createState() => _RegisterEmailViewState();
}

class _RegisterEmailViewState extends State<_RegisterEmailView> {
  // Contact + password controllers
  final _email = TextEditingController();
  final _pwd = TextEditingController();
  final _pwd2 = TextEditingController();

  // OTP controllers/nodes
  final _otpCtrls = List.generate(6, (_) => TextEditingController());
  final _otpNodes = List.generate(6, (_) => FocusNode());

  // User profile controllers
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _username = TextEditingController();

  // Business profile controllers
  final _bizName = TextEditingController();
  final _bizDesc = TextEditingController();
  final _bizWebsite = TextEditingController();

  // Local UI state
  final ImagePicker _picker = ImagePicker();
  bool _stagePassword = false;
  bool _pwdObscure = true;
  bool _pwd2Obscure = true;
  bool _newsletterOptIn = false;
  bool _showAllInterests = true;
  bool _requestedInterests = false;

  // ===== helper: choose Camera/Gallery then pick image =====
  Future<XFile?> _chooseAndPick(
    BuildContext context,
    AppLocalizations t,
  ) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => _ImageSourceSheet(t: t),
    );
    if (source == null) return null;

    try {
      final picked = await _picker.pickImage(
        source: source,
        imageQuality: 85,
        maxWidth: 1600,
        maxHeight: 1600,
      );
      return picked;
    } on PlatformException catch (e) {
      showTopToast(
        context,
        '${t.globalError}: ${e.code}',
        type: ToastType.error,
      );
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final bloc = context.read<RegisterBloc>();
      if (bloc.state.usePhone) bloc.add(RegToggleMethod());
    });
    _pwd.addListener(() => setState(() {}));
    _pwd2.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _email.dispose();
    _pwd.dispose();
    _pwd2.dispose();
    for (final c in _otpCtrls) c.dispose();
    for (final n in _otpNodes) n.dispose();
    _first.dispose();
    _last.dispose();
    _username.dispose();
    _bizName.dispose();
    _bizDesc.dispose();
    _bizWebsite.dispose();
    super.dispose();
  }

  bool _isValidEmail(String v) =>
      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    final emailReady = _isValidEmail(_email.text);
    final signUpReady =
        emailReady && _pwd.text.length >= 8 && _pwd.text == _pwd2.text;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: theme.scaffoldBackgroundColor,
        leading: const BackButton(),
      ),
      body: BlocConsumer<RegisterBloc, RegisterState>(
        listenWhen: (p, c) => p != c,
        listener: (context, s) async {
          if (s.error?.isNotEmpty == true) {
            showTopToast(
              context,
              s.error!,
              type: ToastType.error,
              haptics: true,
            );
          }
          if (s.info?.isNotEmpty == true) {
            showTopToast(context, s.info!, type: ToastType.info);
          }
          if (s.code.length == 6) {
            for (int i = 0; i < 6; i++) {
              _otpCtrls[i].text = s.code[i];
            }
          }

          // ✅ Final navigation on success
          if (s.step == RegStep.done) {
            // If backend issued a token during the register pipeline, attach & go shell
            final token = g.token ?? '';
            if (token.isNotEmpty) {
              g.appDio?.options.headers['Authorization'] = 'Bearer $token';
              // user role by default after register; adjust if your flow registers businesses here
              context.goNamed(
                Routes.shell,
                extra: ShellRouteArgs(
                  role: AppRole.user,
                  token: token,
                  businessId: 0,
                ),
              );
            } else {
              // otherwise, send to login
              context.goNamed(Routes.login);
            }
          }
        },
        builder: (context, s) {
          final bloc = context.read<RegisterBloc>();

          // Lazy-fetch interests when entering that step
          if (s.step == RegStep.interests &&
              !_requestedInterests &&
              !s.interestsLoading &&
              s.interestOptions.isEmpty) {
            _requestedInterests = true;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              bloc.add(RegFetchInterests());
            });
          }

          return SafeArea(
            child: Stack(
              children: [
                SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Role selector
                      Center(
                        child: RoleSelector(
                          value: s.roleIndex,
                          onChanged: (i) => bloc.add(RegRoleChanged(i)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Title
                      Padding(
                        padding: const EdgeInsets.only(top: 8, bottom: 16),
                        child: Text(
                          (!_stagePassword && s.step == RegStep.contact)
                              ? t.emailRegistrationEnterEmail
                              : t.registerTitle,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),

                      // ===== CONTACT (EMAIL) =====
                      if (s.step == RegStep.contact) ...[
                        if (!_stagePassword) ...[
                          AppTextField(
                            controller: _email,
                            label: t.emailRegistrationEmailPlaceholder,
                            hint: t.emailRegistrationEmailPlaceholder,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.done,
                            borderRadius: 28,
                            onChanged: (_) => setState(() {}),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            t.emailRegistrationEmailDesc,
                            style: theme.textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 16),
                          AppButton(
                            onPressed: emailReady
                                ? () => setState(() => _stagePassword = true)
                                : null,
                            label: t.emailRegistrationContinue,
                            expand: true,
                          ),
                          const SizedBox(height: 12),
                          const LoginLink(),
                        ] else ...[
                          Text(
                            t.emailRegistrationCreatePassword,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 8),
                          PasswordInput(
                            controller: _pwd,
                            obscure: _pwdObscure,
                            onToggleObscure: () =>
                                setState(() => _pwdObscure = !_pwdObscure),
                          ),
                          const SizedBox(height: 10),
                          AppTextField(
                            controller: _pwd2,
                            label: t.registerConfirmPassword,
                            hint: t.emailRegistrationPasswordPlaceholder,
                            prefix: const Icon(Icons.lock_outline),
                            suffix: IconButton(
                              icon: Icon(
                                _pwd2Obscure
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                              ),
                              onPressed: () =>
                                  setState(() => _pwd2Obscure = !_pwd2Obscure),
                            ),
                            obscure: _pwd2Obscure,
                            textInputAction: TextInputAction.done,
                            borderRadius: 28,
                          ),
                          const SizedBox(height: 10),
                          const Guidelines(),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Checkbox(
                                value: _newsletterOptIn,
                                onChanged: (v) => setState(
                                  () => _newsletterOptIn = (v ?? false),
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  t.emailRegistrationSaveInfo,
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          AppButton(
                            onPressed: signUpReady
                                ? () {
                                    if (!_isValidEmail(_email.text)) {
                                      showTopToast(
                                        context,
                                        t.emailRegistrationErrorGeneric,
                                        type: ToastType.error,
                                        haptics: true,
                                      );
                                      return;
                                    }
                                    if (s.usePhone) bloc.add(RegToggleMethod());
                                    bloc
                                      ..add(RegEmailChanged(_email.text.trim()))
                                      ..add(
                                        RegPasswordChanged(_pwd.text.trim()),
                                      )
                                      ..add(RegSendVerification());
                                  }
                                : null,
                            label: t.emailRegistrationSignUp,
                            expand: true,
                          ),
                          const SizedBox(height: 12),
                          const LoginLink(),
                        ],
                      ],

                      // ===== OTP =====
                      if (s.step == RegStep.code) ...[
                        const SizedBox(height: 12),
                        Text(
                          t.emailRegistrationVerificationSent,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 18),
                        OtpBoxes(
                          ctrls: _otpCtrls,
                          nodes: _otpNodes,
                          onChanged: (code) => context.read<RegisterBloc>().add(
                            RegCodeChanged(code),
                          ),
                        ),
                        const SizedBox(height: 20),
                        AppButton(
                          onPressed: () =>
                              context.read<RegisterBloc>().add(RegVerifyCode()),
                          label: t.verifyVerifyBtn,
                          expand: true,
                        ),
                        const SizedBox(height: 10),
                        AppButton(
                          onPressed: () =>
                              context.read<RegisterBloc>().add(RegResendCode()),
                          type: AppButtonType.outline,
                          label: t.verifyResendBtn,
                          expand: true,
                        ),
                      ],

                      // ===== USER: NAME =====
                      if (s.step == RegStep.name) ...[
                        const SizedBox(height: 16),
                        Text(
                          t.registerCompleteStep1FirstNameQuestion,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 12),
                        PillField(
                          controller: _first,
                          label: t.registerCompleteStep1FirstName,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegFirstNameChanged(v),
                          ),
                        ),
                        const SizedBox(height: 12),
                        PillField(
                          controller: _last,
                          label: t.registerCompleteStep1LastName,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegLastNameChanged(v),
                          ),
                        ),
                        const SizedBox(height: 16),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().emit(
                            s.copyWith(step: RegStep.username),
                          ),
                          label: t.registerCompleteButtonsContinue,
                          expand: true,
                        ),
                      ],

                      // ===== USER: USERNAME =====
                      if (s.step == RegStep.username) ...[
                        const SizedBox(height: 16),
                        Text(
                          t.registerCompleteStep2ChooseUsername,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 12),
                        PillField(
                          controller: _username,
                          label: t.registerCompleteStep2Username,
                          helper:
                              '${t.registerCompleteStep2UsernameHint1}\n${t.registerCompleteStep2UsernameHint2}\n${t.registerCompleteStep2UsernameHint3}',
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegUsernameChanged(v),
                          ),
                        ),
                        const SizedBox(height: 16),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().emit(
                            s.copyWith(step: RegStep.profile),
                          ),
                          label: t.registerCompleteButtonsContinue,
                          expand: true,
                        ),
                      ],

                      // ===== USER: PROFILE (with Camera/Gallery) =====
                      if (s.step == RegStep.profile) ...[
                        const SizedBox(height: 12),
                        Center(
                          child: GestureDetector(
                            onTap: () async {
                              final img = await _chooseAndPick(context, t);
                              if (img == null) return;
                              context.read<RegisterBloc>().add(
                                RegPickUserImage(img),
                              );
                              showTopToast(
                                context,
                                t.registerAddProfilePhoto,
                                type: ToastType.info,
                              );
                            },
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                CircleAvatar(
                                  radius: 56,
                                  backgroundColor: cs.surfaceVariant,
                                  backgroundImage:
                                      (s.userImage != null &&
                                          s.userImage!.path.isNotEmpty)
                                      ? FileImage(File(s.userImage!.path))
                                      : null,
                                  child:
                                      (s.userImage == null ||
                                          s.userImage!.path.isEmpty)
                                      ? const Icon(Icons.person, size: 48)
                                      : null,
                                ),
                                if (s.userImage != null &&
                                    s.userImage!.path.isNotEmpty)
                                  Positioned(
                                    right: -4,
                                    top: -4,
                                    child: InkWell(
                                      onTap: () => context
                                          .read<RegisterBloc>()
                                          .add(RegPickUserImage(null)),
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: cs.error,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          Icons.close,
                                          size: 16,
                                          color: cs.onError,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SwitchListTile(
                          value: s.userPublic,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegUserPublicToggled(v),
                          ),
                          title: Text(t.registerCompleteStep3PublicProfile),
                        ),
                        const SizedBox(height: 8),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().add(
                            RegSubmitUserProfile(),
                          ),
                          label: t.registerCompleteButtonsFinish,
                          expand: true,
                        ),
                      ],

                      // ===== USER: INTERESTS (REMOTE) =====
                      if (s.step == RegStep.interests) ...[
                        if (s.interestsLoading) ...[
                          const SizedBox(height: 24),
                          const Center(child: CircularProgressIndicator()),
                          const SizedBox(height: 24),
                        ] else if ((s.interestsError ?? '').isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Center(
                            child: Text(
                              t.interestLoadError,
                              textAlign: TextAlign.center,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: theme.colorScheme.error,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          AppButton(
                            onPressed: () => context.read<RegisterBloc>().add(
                              RegFetchInterests(),
                            ),
                            label: t.buttonsContinue,
                            expand: true,
                          ),
                        ] else ...[
                          InterestsGridRemote(
                            items: s.interestOptions,
                            selected: s.interests,
                            showAll: _showAllInterests,
                            onToggleShow: () => setState(
                              () => _showAllInterests = !_showAllInterests,
                            ),
                            onToggle: (id) => context.read<RegisterBloc>().add(
                              RegToggleInterest(id),
                            ),
                            onSubmit: () => context.read<RegisterBloc>().add(
                              RegSubmitInterests(),
                            ),
                          ),
                        ],
                      ],

                      // ===== BUSINESS: NAME =====
                      if (s.step == RegStep.bizName) ...[
                        const SizedBox(height: 16),
                        Text(
                          t.registerCompleteStep1BusinessName,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 12),
                        PillField(
                          controller: _bizName,
                          label: t.registerBusinessName,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegBusinessNameChanged(v),
                          ),
                        ),
                        const SizedBox(height: 16),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().emit(
                            s.copyWith(step: RegStep.bizDetails),
                          ),
                          label: t.registerCompleteButtonsContinue,
                          expand: true,
                        ),
                      ],

                      // ===== BUSINESS: DETAILS =====
                      if (s.step == RegStep.bizDetails) ...[
                        const SizedBox(height: 8),
                        Text(
                          t.registerCompleteStep2BusinessDescription,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        AppTextField(
                          controller: _bizDesc,
                          label: t.registerDescription,
                          maxLines: 4,
                          borderRadius: 18,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegBusinessDescChanged(v),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          t.registerCompleteStep2WebsiteUrl,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        PillField(
                          controller: _bizWebsite,
                          label: t.registerWebsite,
                          onChanged: (v) => context.read<RegisterBloc>().add(
                            RegBusinessWebsiteChanged(v),
                          ),
                        ),
                        const SizedBox(height: 16),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().emit(
                            s.copyWith(step: RegStep.bizProfile),
                          ),
                          label: t.registerCompleteButtonsContinue,
                          expand: true,
                        ),
                      ],

                      // ===== BUSINESS: PROFILE (logo + banner) =====
                      if (s.step == RegStep.bizProfile) ...[
                        Text(
                          t.registerSelectLogo,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        PickBox(
                          label: t.registerSelectLogo,
                          onPick: () async {
                            final img = await _chooseAndPick(context, t);
                            if (img == null) return;
                            context.read<RegisterBloc>().add(
                              RegPickBusinessLogo(img),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        Text(
                          t.registerSelectBanner,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        PickBox(
                          label: t.registerSelectBanner,
                          onPick: () async {
                            final img = await _chooseAndPick(context, t);
                            if (img == null) return;
                            context.read<RegisterBloc>().add(
                              RegPickBusinessBanner(img),
                            );
                          },
                        ),
                        const SizedBox(height: 16),
                        AppButton(
                          onPressed: () => context.read<RegisterBloc>().add(
                            RegSubmitBusinessProfile(),
                          ),
                          label: t.registerCompleteButtonsFinish,
                          expand: true,
                        ),
                      ],

                      // ===== DONE =====
                      if (s.step == RegStep.done) ...[
                        const SizedBox(height: 40),
                        Icon(Icons.check_circle, size: 64, color: cs.primary),
                        const SizedBox(height: 10),
                        Center(
                          child: Text(
                            s.roleIndex == 0
                                ? t.registerSuccessUser
                                : t.registerSuccessBusiness,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        // Friendly button (if listener didn't already redirect)
                        AppButton(
                          onPressed: () => context.goNamed(Routes.login),
                          label: t.buttonsContinue,
                          expand: true,
                        ),
                      ],
                    ],
                  ),
                ),

                if (context.watch<RegisterBloc>().state.loading)
                  Container(
                    color: Colors.black.withOpacity(.12),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(),
                          const SizedBox(height: 10),
                          Text(t.emailRegistrationLoading),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ======================= Bottom sheet for image source =======================
class _ImageSourceSheet extends StatelessWidget {
  final AppLocalizations t;
  const _ImageSourceSheet({required this.t});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                color: cs.outlineVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: Text(t.registerPickFromCamera),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_outlined),
              title: Text(t.registerPickFromGallery),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}
