import 'package:flutter/material.dart';
import 'package:hobby_sphere/l10n/app_localizations.dart';

class RoleSelector extends StatelessWidget {
  final int value; // 0 user, 1 business
  final ValueChanged<int> onChanged;
  const RoleSelector({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _RolePill(label: t.loginUser, selected: value == 0, onTap: () => onChanged(0)),
        const SizedBox(width: 12),
        _RolePill(label: t.loginBusiness, selected: value == 1, onTap: () => onChanged(1)),
      ],
    );
  }
}

class _RolePill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _RolePill({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final bg = selected ? cs.primary.withOpacity(.25) : cs.surface;
    final fg = selected ? cs.primary : cs.onSurface.withOpacity(.8);
    final br = selected ? Colors.transparent : cs.outlineVariant;
    return Material(
      color: bg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: br, width: 1),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Center(child: Text('')),
        ),
      ),
    );
  }
}
