import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:hobby_sphere/core/network/globals.dart' as g;

/// Connection states:
/// - offline: no Wi-Fi/cellular at all
/// - connecting: verifying internet/server reachability
/// - serverDown: internet is fine but your backend is unreachable
/// - connected: internet and backend are reachable
enum ConnectionStateX { offline, connecting, serverDown, connected }

class ConnectionCubit extends Cubit<ConnectionStateX> {
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _sub;
  Timer? _pollTimer;

  ConnectionCubit() : super(ConnectionStateX.connecting) {
    _startMonitoring();
  }

  /// Start listening to OS connectivity and perform initial verification.
  void _startMonitoring() {
    _sub = _connectivity.onConnectivityChanged.listen((results) async {
      final result = results.isNotEmpty
          ? results.first
          : ConnectivityResult.none;

      // No network at all → immediately offline.
      if (result == ConnectivityResult.none) {
        emit(ConnectionStateX.offline);
        _cancelPoll();
        return;
      }

      // Some network exists → start verifying actual internet/server.
      emit(ConnectionStateX.connecting);
      _cancelPoll();
      _verifyLoop();
    });

    _kickoffCheck(); // also check once at startup
  }

  /// Initial one-shot check at app startup.
  Future<void> _kickoffCheck() async {
    final res = await _connectivity.checkConnectivity();
    if (res == ConnectivityResult.none) {
      emit(ConnectionStateX.offline);
      return;
    }

    emit(ConnectionStateX.connecting);
    _verifyOnceAndEmit(); // immediate probe
    _verifyLoop(); // continue probing until we reach a stable state
  }

  /// Periodically verify internet + server reachability until stable.
  void _verifyLoop() {
    _pollTimer = Timer.periodic(const Duration(milliseconds: 2500), (_) {
      _verifyOnceAndEmit();
    });
  }

  /// Single verification pass:
  /// 1) check internet via DNS, 2) probe backend endpoints.
  Future<void> _verifyOnceAndEmit() async {
    // 1) real internet?
    final hasNet = await _hasInternet();
    if (!hasNet) {
      // We have "some" OS connectivity but couldn't confirm internet yet.
      emit(ConnectionStateX.connecting);
      return;
    }

    // 2) backend reachable?
    final serverOk = await _isServerReachable();
    if (serverOk) {
      emit(ConnectionStateX.connected);
      _cancelPoll(); // we reached a stable state
    } else {
      // Internet works but server is unreachable/returning errors.
      emit(ConnectionStateX.serverDown);
      // Keep polling so the state auto-recovers when backend comes back.
    }
  }

  /// Fast DNS lookup to confirm actual internet access.
  Future<bool> _hasInternet() async {
    try {
      final res = await InternetAddress.lookup('example.com');
      return res.isNotEmpty && res.first.rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// Probe your backend with quick GETs to a few candidate paths.
  /// Adjust the candidate list to match your server.
  Future<bool> _isServerReachable() async {
    final base = (g.appServerRoot ?? '').trim(); // e.g. http://host:8080/api
    if (base.isEmpty) return false;

    final dio = Dio(
      BaseOptions(
        baseUrl: base,
        connectTimeout: const Duration(seconds: 3),
        receiveTimeout: const Duration(seconds: 3),
        sendTimeout: const Duration(seconds: 3),
        followRedirects: false,
        validateStatus: (_) => true, // treat any HTTP code as a response
      ),
    );

    // Try a few lightweight endpoints. Put your health endpoint first if you have one.
    final candidates = <String>[
      '/health',
      '/ping',
      '/item-types',
      '/', // last resort
    ];

    for (final path in candidates) {
      try {
        final r = await dio.get(path);
        if (r.statusCode != null && r.statusCode! < 400) return true;
      } catch (_) {
        // try next candidate
      }
    }
    return false;
  }

  /// Triggered by the "Try again" button.
  void retryNow() {
    emit(ConnectionStateX.connecting);
    _cancelPoll();
    _verifyLoop();
  }

  void _cancelPoll() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  @override
  Future<void> close() {
    _cancelPoll();
    _sub?.cancel();
    return super.close();
  }
}
