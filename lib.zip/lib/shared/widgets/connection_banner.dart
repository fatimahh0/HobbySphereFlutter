import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../network/connection_cubit.dart';
import 'package:hobby_sphere/l10n/app_localizations.dart';

/// A thin top banner that appears while offline/connecting/server down.
/// Hide it entirely when connected.
class ConnectionBanner extends StatelessWidget {
  const ConnectionBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ConnectionCubit, ConnectionStateX>(
      builder: (context, state) {
        if (state == ConnectionStateX.connected) {
          return const SizedBox.shrink();
        }

        final cs = Theme.of(context).colorScheme;
        final t = AppLocalizations.of(context)!;

        // Pick background color and text per state.
        Color bg;
        String text;

        switch (state) {
          case ConnectionStateX.offline:
            bg = cs.errorContainer;
            text = t.connectionOffline; // "Not connected"
            break;
          case ConnectionStateX.serverDown:
            bg = cs.surfaceContainerHigh;
            text = t.connectionServerDown; // "Server unavailable"
            break;
          case ConnectionStateX.connecting:
          default:
            bg = cs.surfaceContainerHighest;
            text = t.connectionConnecting; // "Connecting…"
            break;
        }

        return Material(
          color: bg,
          elevation: 2,
          child: SafeArea(
            bottom: false,
            child: Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  if (state == ConnectionStateX.connecting)
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  if (state == ConnectionStateX.connecting)
                    const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: cs.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (state == ConnectionStateX.offline ||
                      state == ConnectionStateX.serverDown)
                    TextButton(
                      onPressed: () =>
                          context.read<ConnectionCubit>().retryNow(),
                      child: Text(
                        t.connectionTryAgain, // "Try again"
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: cs.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
