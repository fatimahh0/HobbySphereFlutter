// keep client ids in one place (easy to change per flavor)
class GoogleClientIds {
  // your Web client ID (you gave me this value)
  static const web =
      '851915342014-j24igdgk6pvfqh4hu6pbs65jtp6a1r0k.apps.googleusercontent.com'; // web client id
}
