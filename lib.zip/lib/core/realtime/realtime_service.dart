// Flutter 3.35.x
// WebSocket client with: Authorization header, multiple path fallbacks,
// exponential backoff, safe JSON (handles bytes), dedupe by eventId,
// optional version guard, and a connection status notifier.

import 'dart:async'; // Timer, StreamSubscription
import 'dart:convert'; // jsonDecode, utf8.decode
import 'package:flutter/foundation.dart'; // ValueNotifier
import 'package:web_socket_channel/io.dart'; // IOWebSocketChannel

import 'event_models.dart'; // RealtimeEvent
import 'realtime_bus.dart'; // RealtimeBus
import 'retry.dart'; // ExponentialBackoff

class RealtimeService {
  IOWebSocketChannel? _ch; // current channel (null if closed)
  Timer? _ping; // heartbeat timer
  final _backoff = ExponentialBackoff(); // backoff calculator

  // connection flags
  bool _connecting = false; // prevent double connect attempts
  bool _manual = false; // true when we close on purpose

  // config saved for reconnect
  late String _httpBase; // e.g., http://host:8080   (no /api)
  late String _token; // JWT token (payload only)
  List<String> _paths = const [
    '/ws',
    '/ws/events',
    '/realtime',
    '/socket',
  ]; // candidate paths
  int _pathIndex = 0; // which path we are trying now

  // small caches
  final Set<String> _seen = <String>{}; // dedupe by eventId
  final Map<int, int> _lastVersion =
      <int, int>{}; // last version per resourceId

  // public connection status (for a small "Live" badge)
  final ValueNotifier<bool> isConnected = ValueNotifier<bool>(
    false,
  ); // true when live

  /// Connect socket using HTTP base (no /api) and JWT.
  /// You can pass custom candidate paths if your server mounts elsewhere.
  void connect({
    required String httpBase, // server root
    required String token, // JWT token
    List<String>? candidatePaths, // optional custom paths
  }) {
    _manual = false; // we want auto-reconnect
    _httpBase = httpBase; // save base
    _token = token; // save token
    if (candidatePaths != null && candidatePaths.isNotEmpty) {
      _paths = candidatePaths; // override paths if provided
    }
    _pathIndex = 0; // start from first path
    _open(); // try to open
  }

  /// Reconnect with a new JWT (after token refresh).
  void reconnectWithToken(String token) {
    _token = token; // update token
    _close(); // close current channel
    _open(); // reopen with new token
  }

  // ----- internal: open the channel (with path fallback) -----
  void _open() {
    if (_connecting) return; // already trying
    _connecting = true; // lock connect

    final wsUrl = _buildWsUrl(_paths[_pathIndex]); // build full ws url
    if (!wsUrl.startsWith('ws://') && !wsUrl.startsWith('wss://')) {
      _connecting = false; // unlock connect
      _scheduleReconnect(); // schedule retry
      return; // stop here
    }

    // try to connect
    try {
      _ch = IOWebSocketChannel.connect(
        // open socket
        Uri.parse(wsUrl), // ws://host:port/path
        headers: {'Authorization': 'Bearer $_token'}, // attach auth header
      );

      // listen to incoming frames
      _ch!.stream.listen(
        _onRawMessage, // handle each frame
        onDone: _onDone, // socket closed
        onError: _onError, // socket error
        cancelOnError: true, // stop stream on error
      );

      _onOpen(); // mark connected
    } catch (_) {
      _connecting = false; // unlock
      _tryNextPathOrBackoff(); // try another path or backoff
    }
  }

  // build ws:// url from http base + path
  String _buildWsUrl(String path) {
    final u = Uri.parse(_httpBase); // parse base
    final scheme = (u.scheme == 'https') ? 'wss' : 'ws'; // choose ws/wss
    final host = u.host; // host
    final port = u.hasPort ? ':${u.port}' : ''; // port string
    final p = path.startsWith('/') ? path : '/$path'; // ensure leading /
    return '$scheme://$host$port$p'; // full url
  }

  // called once connected
  void _onOpen() {
    _connecting = false; // no longer connecting
    _backoff.reset(); // reset backoff to base
    isConnected.value = true; // mark live
    _startPing(); // start heartbeat timer
  }

  // handle each incoming frame safely
  void _onRawMessage(dynamic raw) {
    try {
      // normalize to string (server may send bytes)
      final text = raw is String
          ? raw
          : utf8.decode(raw as List<int>); // bytes → text
      // parse json payload
      final map = jsonDecode(text) as Map<String, dynamic>; // string → map
      // build event object
      final ev = RealtimeEvent.fromJson(map); // map → event

      // ----- dedupe by eventId (skip duplicates) -----
      if (ev.eventId.isNotEmpty) {
        // event has id?
        if (_seen.contains(ev.eventId)) return; // already processed
        _seen.add(ev.eventId); // mark as seen
        if (_seen.length > 1000) _seen.clear(); // simple cap (avoid growth)
      }

      // ----- optional ordering guard by version -----
      if (ev.version != null) {
        // server sent version?
        final last = _lastVersion[ev.resourceId] ?? -1; // read last
        if (ev.version! < last) return; // older event → drop
        _lastVersion[ev.resourceId] = ev.version!; // update last version
      }

      // broadcast to the whole app
      RealtimeBus.I.emit(ev); // push to bus
    } catch (_) {
      // ignore bad frames (keep socket alive)
    }
  }

  // closed by server or network
  void _onDone() {
    _stopPing(); // stop heartbeat
    _clearChannel(); // drop channel
    isConnected.value = false; // mark offline
    if (_manual) return; // if manual close → stop here
    _tryNextPathOrBackoff(); // else retry
  }

  // error on stream
  void _onError(Object _) {
    _stopPing(); // stop heartbeat
    _clearChannel(); // drop channel
    isConnected.value = false; // mark offline
    if (_manual) return; // manual close → stop
    _tryNextPathOrBackoff(); // else retry
  }

  // try next path first, then backoff
  void _tryNextPathOrBackoff() {
    if (_pathIndex < _paths.length - 1) {
      // more paths available?
      _pathIndex++; // move to next
      Future.delayed(const Duration(milliseconds: 300), _open); // quick retry
      return; // done
    }
    _pathIndex = 0; // reset to first path
    _scheduleReconnect(); // backoff retry
  }

  // schedule reconnect with exponential backoff
  void _scheduleReconnect() {
    final wait = _backoff.next(); // compute delay
    Future.delayed(wait, _open); // wait then open
  }

  // heartbeat ping (keep connection alive)
  void _startPing() {
    _ping?.cancel(); // clear old timer
    _ping = Timer.periodic(const Duration(seconds: 20), (_) {
      try {
        _ch?.sink.add('{"type":"ping"}');
      } // send simple ping
      catch (_) {} // ignore send error
    });
  }

  // stop heartbeat timer
  void _stopPing() => _ping?.cancel();

  // clear channel reference (avoid leaks)
  void _clearChannel() {
    _ch = null; // mark closed
  }

  // close socket on purpose (no auto-reconnect)
  void _close() {
    _stopPing(); // stop heartbeat
    _manual = true; // stop future reconnects
    try {
      _ch?.sink.close();
    } catch (_) {} // ask server to close
    _clearChannel(); // null channel
  }

  // public dispose (same as close)
  void dispose() => _close();
}
