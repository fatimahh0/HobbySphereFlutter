// Flutter 3.35.x
// Broadcast bus so any screen can listen to realtime events.

import 'dart:async'; // StreamController
import 'event_models.dart'; // RealtimeEvent

class RealtimeBus {
  RealtimeBus._(); // private constructor
  static final RealtimeBus I = RealtimeBus._(); // singleton instance

  final _ctrl = StreamController<RealtimeEvent>.broadcast(); // broadcast stream

  Stream<RealtimeEvent> get stream => _ctrl.stream; // listen here
  void emit(RealtimeEvent e) => _ctrl.add(e); // push event to listeners
  void dispose() => _ctrl.close(); // close on app shutdown
}
