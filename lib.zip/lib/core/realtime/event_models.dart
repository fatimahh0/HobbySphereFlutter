// Flutter 3.35.x
// One event model used by all app parts (user + business).

enum Domain {
  activity,
  booking,
  profile,
  notification,
  user,
  review,
  analytics,
  // social
  post,
  comment,
  like,
  // NEW — chat + friendships
  chat,
  message,
  friendship,
}

enum ActionType { created, updated, deleted, reopened, statusChanged }

Domain _domainFrom(String s) {
  switch (s.toLowerCase()) {
    case 'activity':
      return Domain.activity;
    case 'booking':
      return Domain.booking;
    case 'profile':
      return Domain.profile;
    case 'notification':
      return Domain.notification;
    case 'user':
      return Domain.user;
    case 'review':
      return Domain.review;
    case 'analytics':
      return Domain.analytics;
    case 'post':
      return Domain.post;
    case 'comment':
      return Domain.comment;
    case 'like':
      return Domain.like;
    case 'chat':
      return Domain.chat;
    case 'message':
      return Domain.message;
    case 'friendship':
      return Domain.friendship;
  }
  return Domain.activity;
}

ActionType _actionFrom(String s) {
  switch (s.toLowerCase()) {
    case 'created':
      return ActionType.created;
    case 'updated':
      return ActionType.updated;
    case 'deleted':
      return ActionType.deleted;
    case 'reopened':
      return ActionType.reopened;
    case 'statuschanged':
      return ActionType.statusChanged;
  }
  return ActionType.updated;
}

class RealtimeEvent {
  final String eventId;
  final Domain domain;
  final ActionType action;
  final int businessId;
  final int resourceId;
  final int? version;
  final DateTime? ts;
  final Map<String, dynamic>? data;

  RealtimeEvent({
    required this.eventId,
    required this.domain,
    required this.action,
    required this.businessId,
    required this.resourceId,
    this.version,
    this.ts,
    this.data,
  });

  factory RealtimeEvent.fromJson(Map<String, dynamic> m) => RealtimeEvent(
    eventId: (m['eventId'] ?? '').toString(),
    domain: _domainFrom((m['domain'] ?? '').toString()),
    action: _actionFrom((m['action'] ?? '').toString()),
    businessId: (m['businessId'] ?? 0) as int,
    resourceId: (m['resourceId'] ?? 0) as int,
    version: (m['version'] is int) ? m['version'] as int : null,
    ts: (m['ts'] is String) ? DateTime.tryParse(m['ts']) : null,
    data: (m['data'] is Map<String, dynamic>)
        ? (m['data'] as Map<String, dynamic>)
        : null,
  );
}
