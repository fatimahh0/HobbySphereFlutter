// Flutter 3.35.x
// Global "Instant" manager: register lightweight loaders for each screen/tab,
// keep data in RAM with TTL, persist to disk, precache images,
// show stale data instantly, refresh silently (SWR).

import 'dart:async'; // Future
import 'dart:convert'; // json Encode/Decode
import 'package:flutter/widgets.dart'; // BuildContext + precacheImage
import 'package:shared_preferences/shared_preferences.dart'; // disk store
import 'package:hobby_sphere/core/cache/simple_cache.dart'; // RAM cache

// Each loader returns a JSON-like Map for that screen/tab.
typedef InstantLoader =
    Future<Map<String, dynamic>> Function(BuildContext? ctx);

// Internal entry containing RAM cache, disk key, ttl, and the loader.
class _Entry {
  final SimpleCache<Map<String, dynamic>> ram; // RAM cache for this screen
  final String diskKey; // SharedPreferences key
  final int ttlSeconds; // freshness window in seconds
  final InstantLoader loader; // how to fetch data
  _Entry({
    required this.ram, // cache
    required this.diskKey, // disk key
    required this.ttlSeconds, // ttl
    required this.loader, // function
  });
}

// Singleton-style manager with static methods.
class Instant {
  static final Map<String, _Entry> _registry = {}; // holds all loaders

  // Register one loader (call once in main()).
  static void register({
    required String name, // unique id, e.g., 'user.home'
    required String diskKey, // preference key, e.g., 'ih_user_home'
    required int ttlSeconds, // how long RAM stays fresh
    required InstantLoader loader, // fetch function
  }) {
    _registry[name] = _Entry(
      ram: SimpleCache<Map<String, dynamic>>(), // per-screen RAM cache
      diskKey: diskKey, // disk key
      ttlSeconds: ttlSeconds, // ttl
      loader: loader, // loader func
    );
  }

  // Preload now → fills RAM + writes disk + optional image warmup.
  static Future<Map<String, dynamic>> preload(
    String name, {
    BuildContext? ctx, // optional for image precache
  }) async {
    final e = _registry[name]!; // get entry
    // Use RAM cache with TTL (runs loader once if stale/empty).
    final data = await e.ram.getOrLoad(
      () => e.loader(ctx),
      ttlSeconds: e.ttlSeconds,
    );
    // Save to disk for instant next launch.
    final sp = await SharedPreferences.getInstance(); // prefs
    await sp.setString(e.diskKey, jsonEncode(data)); // store json
    // If loader provided 'thumbs' list → precache images (faster first paint).
    final thumbs = data['thumbs'];
    if (ctx != null && thumbs is List) {
      for (final t in thumbs.take(8)) {
        if (t is String && t.isNotEmpty) {
          precacheImage(NetworkImage(t), ctx); // warm network image
        }
      }
    }
    return data; // return data
  }

  // Read stale from disk synchronously (fast) to paint UI instantly.
  static Future<Map<String, dynamic>?> readStale(String name) async {
    final e = _registry[name]!; // entry
    final sp = await SharedPreferences.getInstance(); // prefs
    final raw = sp.getString(e.diskKey); // json text
    if (raw == null) return null; // not saved before
    try {
      return jsonDecode(raw) as Map<String, dynamic>; // parse map
    } catch (_) {
      return null; // invalid json
    }
  }

  // Try to get fresh RAM value (if still within TTL).
  static Map<String, dynamic>? getFresh(String name) {
    return _registry[name]!.ram.getIfFresh(); // may be null
  }

  // Silent refresh (SWR): updates RAM+disk, but never blocks UI.
  static Future<Map<String, dynamic>?> refresh(
    String name, {
    BuildContext? ctx, // optional image warmup
  }) async {
    try {
      return await preload(name, ctx: ctx); // reuse preload
    } catch (_) {
      return null; // ignore small errors
    }
  }

  // Clear only RAM caches (use on logout or account switch).
  static void clear() {
    for (final e in _registry.values) {
      e.ram.clear(); // drop in-memory values
    }
  }
}
