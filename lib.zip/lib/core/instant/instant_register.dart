// Flutter 3.35.x
// Register all loaders (user + business + explore + community + tickets + analytics).
// Call InstantRegister.init() once in main() AFTER Dio/token are ready.

import 'package:flutter/widgets.dart'; // BuildContext (type only)
import 'package:hobby_sphere/core/instant/instant_manager.dart'; // Instant
import 'package:hobby_sphere/core/network/globals.dart' as g; // global Dio

class InstantRegister {
  // Initialize registry for all important tabs/screens.
  static void init() {
    // ===== USER: HOME =====
    Instant.register(
      name: 'user.home', // unique name
      diskKey: 'ih_user_home', // disk key
      ttlSeconds: 30, // fast changing feed
      loader: (ctx) async {
        // Fetch in parallel: feed + counts + lookups.
        final r = await Future.wait([
          g.appDio!.get('/api/items/feed?page=1&limit=12'), // feed first page
          g.appDio!.get('/api/chat/unread-count'), // unread count
          g.appDio!.get('/api/notifications/count'), // notifications count
          g.appDio!.get('/api/item-types'), // lookup: item types
          g.appDio!.get('/api/currencies'), // lookup: currencies
        ]);

        // Extract lists and counts safely.
        final items = (r[0].data['items'] as List?) ?? <dynamic>[]; // list
        final unread = (r[1].data['count'] as int?) ?? 0; // int
        final notif = (r[2].data['count'] as int?) ?? 0; // int
        final types = (r[3].data as List?) ?? <dynamic>[]; // list
        final currs = (r[4].data as List?) ?? <dynamic>[]; // list

        // Collect thumbnails for precache (optional).
        final thumbs = <String>[]; // list of urls
        for (final it in items.take(8)) {
          final url = (it as Map)['thumbnailUrl'] as String?; // adjust field
          if (url != null && url.isNotEmpty) thumbs.add(url); // keep url
        }

        // Return a compact JSON-like map for the screen.
        return {
          'feed': items, // list of items/cards
          'unread': unread, // int
          'notif': notif, // int
          'types': types, // list
          'curr': currs, // list
          'thumbs': thumbs, // image warmup list
        };
      },
    );

    // ===== USER: EXPLORE =====
    Instant.register(
      name: 'user.explore', // key
      diskKey: 'ih_user_explore', // disk key
      ttlSeconds: 60, // medium change
      loader: (_) async {
        final r = await g.appDio!.get(
          '/api/items/explore?page=1&limit=12',
        ); // GET
        return {'items': (r.data['items'] as List?) ?? <dynamic>[]}; // payload
      },
    );

    // ===== USER: COMMUNITY =====
    Instant.register(
      name: 'user.community', // key
      diskKey: 'ih_user_community', // disk key
      ttlSeconds: 45, // medium
      loader: (_) async {
        final r = await g.appDio!.get(
          '/api/community/feed?page=1&limit=12',
        ); // GET
        return {'posts': (r.data['items'] as List?) ?? <dynamic>[]}; // payload
      },
    );

    // ===== USER: TICKETS =====
    Instant.register(
      name: 'user.tickets', // key
      diskKey: 'ih_user_tickets', // disk key
      ttlSeconds: 45, // medium
      loader: (_) async {
        final r = await g.appDio!.get('/api/bookings/my?status=pending'); // GET
        return {
          'pending': (r.data['items'] as List?) ?? <dynamic>[],
        }; // payload
      },
    );

    // ===== USER: PROFILE =====
    Instant.register(
      name: 'user.profile', // key
      diskKey: 'ih_user_profile', // disk key
      ttlSeconds: 300, // slow changes
      loader: (_) async {
        final r = await g.appDio!.get('/api/profile/me'); // GET
        return {
          'me': r.data as Map<String, dynamic>? ?? <String, dynamic>{},
        }; // payload
      },
    );

    // ===== BUSINESS: HOME =====
    Instant.register(
      name: 'biz.home', // key
      diskKey: 'ih_biz_home', // disk key
      ttlSeconds: 30, // fast dashboard
      loader: (ctx) async {
        final r = await Future.wait([
          g.appDio!.get('/api/business/activities/next?limit=8'), // next events
          g.appDio!.get('/api/business/kpis'), // KPIs overview
        ]);
        final items = (r[0].data['items'] as List?) ?? <dynamic>[]; // list
        final kpis = (r[1].data as Map?) ?? <String, dynamic>{}; // map

        // Precache thumbnails for upcoming activities.
        final thumbs = <String>[]; // urls
        for (final it in items.take(6)) {
          final url = (it as Map)['thumbnailUrl'] as String?; // adjust field
          if (url != null && url.isNotEmpty) thumbs.add(url); // keep
        }

        return {'next': items, 'kpis': kpis, 'thumbs': thumbs}; // payload
      },
    );

    // ===== BUSINESS: BOOKINGS =====
    Instant.register(
      name: 'biz.bookings', // key
      diskKey: 'ih_biz_bookings', // disk key
      ttlSeconds: 45, // medium
      loader: (_) async {
        final r = await g.appDio!.get(
          '/api/business/bookings?status=pending',
        ); // GET
        return {
          'pending': (r.data['items'] as List?) ?? <dynamic>[],
        }; // payload
      },
    );

    // ===== BUSINESS: ANALYTICS =====
    Instant.register(
      name: 'biz.analytics', // key
      diskKey: 'ih_biz_analytics', // disk key
      ttlSeconds: 90, // medium/slow
      loader: (_) async {
        final r = await g.appDio!.get(
          '/api/business/analytics/overview',
        ); // GET
        return {
          'overview': r.data as Map<String, dynamic>? ?? <String, dynamic>{},
        }; // map
      },
    );

    // ===== BUSINESS: ACTIVITIES LIST =====
    Instant.register(
      name: 'biz.activities', // key
      diskKey: 'ih_biz_activities', // disk key
      ttlSeconds: 60, // medium
      loader: (_) async {
        final r = await g.appDio!.get(
          '/api/business/activities?page=1&limit=12',
        ); // GET
        return {'items': (r.data['items'] as List?) ?? <dynamic>[]}; // list
      },
    );
  }
}
