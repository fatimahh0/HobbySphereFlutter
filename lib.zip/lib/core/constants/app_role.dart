// Flutter 3.35.x
// Who is logged in now? User, Business, or Guest.
enum AppRole { user, business, guest } // guest = not logged in
