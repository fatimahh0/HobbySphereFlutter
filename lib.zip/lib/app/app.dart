// lib/app.dart — minimal additions to load backend colors and rebuild UI.
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// i18n & theme
import 'package:hobby_sphere/l10n/app_localizations.dart' show AppLocalizations;
import 'package:hobby_sphere/shared/theme/app_theme.dart' show AppTheme;

// ✅ Use the new router (GoRouter-based)
import 'router/router.dart';

// connection banner (unchanged)
import 'package:hobby_sphere/shared/network/connection_cubit.dart';
import 'package:hobby_sphere/shared/widgets/connection_banner.dart';

// server config (unchanged)
import 'package:hobby_sphere/core/network/api_config.dart';

// >>> NEW: imports for theme fetch + palette <<<
import 'package:hobby_sphere/features/activities/common/data/services/theme_service.dart'; // fetch JSON
import 'package:hobby_sphere/shared/theme/palette.dart'; // Palette.I (runtime colors)

class App extends StatefulWidget {
  final ApiConfig config; // has baseUrl + serverRoot
  const App({super.key, required this.config});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  static const _kThemeKey = 'themeMode'; // saved theme
  static const _kLocaleKey = 'locale'; // saved locale

  ThemeMode _themeMode = ThemeMode.light; // default
  Locale _locale = const Locale('en'); // default

  // Used by ConnectionCubit
  late final String _serverProbeUrl =
      '${widget.config.serverRoot}/actuator/health';

  // >>> NEW: create service once <<<
  final _themeService = ThemeService(); // backend theme service

  @override
  void initState() {
    super.initState();
    _restorePrefs(); // restore local theme/locale
    _loadThemeFromBackendOnce(); // fetch backend colors once
  }

  Future<void> _restorePrefs() async {
    final sp = await SharedPreferences.getInstance();
    final t = sp.getString(_kThemeKey);
    final l = sp.getString(_kLocaleKey);
    if (t != null) {
      _themeMode = (t == 'dark') ? ThemeMode.dark : ThemeMode.light;
    }
    if (l != null) {
      _locale = Locale(l);
    }
    if (mounted) setState(() {});
  }

  Future<void> _persistTheme(ThemeMode mode) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kThemeKey, mode == ThemeMode.dark ? 'dark' : 'light');
  }

  Future<void> _persistLocale(Locale locale) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kLocaleKey, locale.languageCode);
  }

  void _toggleTheme() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.light
          ? ThemeMode.dark
          : ThemeMode.light;
    });
    _persistTheme(_themeMode);
  }

  void _changeLocale(Locale locale) {
    setState(() => _locale = locale);
    _persistLocale(locale);
  }

  // >>> NEW: call backend and apply to Palette.I
  Future<void> _loadThemeFromBackendOnce() async {
    try {
      final json = await _themeService.getActiveMobileTheme(); // GET theme JSON
      Palette.I.applyMobileThemeJson(json); // mutate runtime colors
      // AnimatedBuilder below listens to Palette.I and rebuilds MaterialApp.
    } catch (_) {
      // ignore errors: keep safe defaults
    }
  }

  @override
  Widget build(BuildContext context) {
    // ✅ Build the GoRouter config here (no onGenerateRoute)
    final routerConfig = AppRouter.build(
      enabledFeatures: const ['activity'], // later: add 'product'
      onToggleTheme: _toggleTheme,
      onChangeLocale: _changeLocale,
      getCurrentLocale: () => _locale,
    );

    return BlocProvider(
      create: (_) => ConnectionCubit(serverProbeUrl: _serverProbeUrl),

      // ✅ Rebuild MaterialApp when runtime palette changes
      child: AnimatedBuilder(
        animation: Palette.I,
        builder: (_, __) {
          return MaterialApp.router(
            debugShowCheckedModeBanner: false,
            title: 'Hobby Sphere',

            // ✅ Use the GoRouter config
            routerConfig: routerConfig,

            // Theming & i18n
            themeMode: _themeMode,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            locale: _locale,
            localizationsDelegates: AppLocalizations.localizationsDelegates,
            supportedLocales: AppLocalizations.supportedLocales,

            // Keep your connection banner on top of every page
            builder: (context, child) {
              return Stack(
                children: [
                  if (child != null) child,
                  const Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: ConnectionBanner(),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
